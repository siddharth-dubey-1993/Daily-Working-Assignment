package com.cybage.qualitymanagement.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TestPlan")
public class TestPlanModel implements Serializable {

	private static final long serialVersionUID = 1L;
	Integer testPlanId;
	String testPlanTitle;
	String testPlanDescription;
	String testPlanStatus;
	String testPlanType;
	Set<TestCaseModel> testCases;


	public TestPlanModel() {
		System.out.println("in testplan  constr");
	}


	public TestPlanModel(Integer testPlanId, String testPlanTitle, String testPlanDescription, String testPlanStatus,
			String testPlanType) {
		super();
		this.testPlanId = testPlanId;
		this.testPlanTitle = testPlanTitle;
		this.testPlanDescription = testPlanDescription;
		this.testPlanStatus = testPlanStatus;
		this.testPlanType = testPlanType;
	}

	@Id
	@GeneratedValue
	@Column(name = "testplan_id")
	public Integer getTestPlanId() {
		return testPlanId;
	}


	public void setTestPlanId(Integer testPlanId) {
		this.testPlanId = testPlanId;
	}

	@Column(name= "testplan_title",length = 30)
	public String getTestPlanTitle() {
		return testPlanTitle;
	}


	public void setTestPlanTitle(String testPlanTitle) {
		this.testPlanTitle = testPlanTitle;
	}

	@Column(name= "testplan_description",length = 30)
	public String getTestPlanDescription() {
		return testPlanDescription;
	}


	public void setTestPlanDescription(String testPlanDescription) {
		this.testPlanDescription = testPlanDescription;
	}

	@Column(name= "testplan_status",length = 30)
	public String getTestPlanStatus() {
		return testPlanStatus;
	}


	public void setTestPlanStatus(String testPlanStatus) {
		this.testPlanStatus = testPlanStatus;
	}

	@Column(name= "testplan_type",length = 30)
	public String getTestPlanType() {
		return testPlanType;
	}

	public void setTestPlanType(String testPlanType) {
		this.testPlanType = testPlanType;
	}

	@OneToMany(cascade = CascadeType.ALL,
			mappedBy = "testPlan",fetch=FetchType.EAGER)
	public Set<TestCaseModel> getTestCases() {
		return testCases;
	}


	public void setTestCases(Set<TestCaseModel> testCases) {
		this.testCases = testCases;
	}


	@Override
	public String toString() {
		/*StringBuilder sb = new StringBuilder(" \n TestCase's title ");
		for (TestCaseModel testcaseModel : testCases)
			sb.append(testcaseModel.getTitle() + " ");*/
		return "TestPlan Id=" + testPlanId 
				+ ", TestPlan Title=" + testPlanTitle 
				+ ", TestPlan Description="+ testPlanDescription 
				+ ", TestPlan Status=" + testPlanStatus 
				+ ", TestPlan Type=" + testPlanType
				/*+ sb.toString()*/ ;
	}

	//Convenience Method to add & delete test cases to a test plan
	public boolean addTestcaseModel(TestCaseModel testCaseModel) {
		if (testCases.add(testCaseModel)) {
			testCaseModel.setTestPlan(this);
			return true;
		}
		return false;

	}

	public boolean removeStudent(TestCaseModel testCaseModel) {
		return testCases.remove(testCaseModel);
	}

}
