package com.cybage.qualitymanagement.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestPlanService;

@Service
@Transactional
public class TestPlanServiceImpl implements TestPlanService {

	@Autowired
	TestPlanDao testPlanDao;

	public TestPlanServiceImpl() {
	System.out.println("in service impl");
	}
	
	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel) {
		
		TestPlanModel tpModel1=testPlanDao.addTestPlan(testPlanModel);
		System.out.println("Dao Returned");
		return tpModel1;	
	}
	
	@Override
	public TestPlanModel getTestPlan(){
		return testPlanDao.getTestPlan();
	}

	@Override
	public TestPlanModel getTestPlanByTitle(String planTitle) {
		return testPlanDao.getTestPlanByTitle(planTitle);
	}

	
}
