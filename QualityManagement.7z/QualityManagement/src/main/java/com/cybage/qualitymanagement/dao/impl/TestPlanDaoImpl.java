package com.cybage.qualitymanagement.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.Employee;
import com.cybage.qualitymanagement.model.Project;
import com.cybage.qualitymanagement.model.ResourceProjectTable;
import com.cybage.qualitymanagement.model.RoleTable;
import com.cybage.qualitymanagement.model.TestPlanModel;


@Repository
public class TestPlanDaoImpl implements TestPlanDao {
	
	@Autowired
	SessionFactory sf;
	
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	public TestPlanDaoImpl() {
	System.out.println("in dao impl");
	}
	
	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel){
		System.out.println("addTestPlan() Dao");
		 Session session=sf.getCurrentSession();
		 session.save(testPlanModel);
		 System.out.println("get role list");
		 
		 List<Object[]> list1= session.createQuery
				 ("select p.proj_name, t.TEid from Project p left join p.teamEmpidTables t")
				 .list();
		 for (Object[] aRow : list1) {
			 for (Object object : aRow) {
				System.out.print(object+ "  ");
			}
			 System.out.println("row ended");
			 System.out.println();
			/* System.out.println("Roleqqqq:" +aRow);
			Integer role1=(Integer) aRow[0];
			 String proj1=(String) aRow[1];
			System.out.println("Role:" +role1);
			System.out.println("Project: "+proj1);*/
		}
		
		 
		 System.out.println("Line Before Dao returns");
		 /*Integer empid=(Integer)session.save(new Employee("Engg","Sw Engg","Mnrm"));
		 System.out.println("EmpID: "+empid);
		 
		 //session.flush();
		 System.out.println("Emp Details"+session.get(Employee.class,empid));
		// session.close();
*/		 return testPlanModel;
	}
	
	@Override
	public TestPlanModel getTestPlan() {
		/*
		 * @SuppressWarnings("unchecked") ArrayList<String>
		 * c=(ArrayList<String>) sf.getCurrentSession() .createQuery(
		 * "select c.testPlanTitle from TestPlan c") .list(); return c;
		 */
		TestPlanModel testPlanModel = (TestPlanModel) hibernateTemplate.get(TestPlanModel.class, 1);
		return testPlanModel;
	}

	@Override
	public TestPlanModel getTestPlanByTitle(String planTitle) {
		TestPlanModel testPlanModel = (TestPlanModel) sf.getCurrentSession()
				.createQuery("select c from TestPlanModel c where c.testPlanTitle = :title")
				.setParameter("title", planTitle)
				.uniqueResult();
	
		return testPlanModel;
	}
}
