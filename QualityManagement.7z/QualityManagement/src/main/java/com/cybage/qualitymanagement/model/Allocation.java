package com.cybage.qualitymanagement.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the role_table database table.
 * 
 */
@Entity
@Table(name="allocation_table")
@NamedQuery(name="Allocation.findAll", query="SELECT r FROM Allocation r")
public class Allocation  {
	private static final long serialVersionUID = 1L;
	private int allocationId;
	private String role;
	private Employee employee;
	private Project projectTable;

	public Allocation() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getRole_id() {
		return this.allocationId;
	}

	public void setRole_id(int role_id) {
		this.allocationId = role_id;
	}


	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}


	//bi-directional many-to-one association to Employee
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Empid")
	public Employee getEmployee() {
		return this.employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}


	//bi-directional many-to-one association to Project
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Proj_id")
	public Project getProjectTable() {
		return this.projectTable;
	}

	public void setProjectTable(Project projectTable) {
		this.projectTable = projectTable;
	}


	@Override
	public String toString() {
		return "RoleTable [role_id=" + allocationId + ", role=" + role + "]";
	}

	
}