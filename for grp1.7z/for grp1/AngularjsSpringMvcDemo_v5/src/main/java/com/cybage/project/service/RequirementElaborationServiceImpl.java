package com.cybage.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.project.dao.AttachmentDao;
import com.cybage.project.dao.RequirementElaborationDao;
import com.cybage.project.model.DtoToPojoConverter;
import com.cybage.project.model.Requirement;
import com.cybage.project.model.RequirementDTO;
import com.cybage.project.model.RequirementElaboration;

@Service
@Transactional 
public class RequirementElaborationServiceImpl implements RequirementElaborationService {
	@Autowired
	private RequirementElaborationDao requirementElaborationDao;
	
	@Autowired
	private DtoToPojoConverter dtoToPojoConverter;
	
	@Override
	public Integer  saveRequirementElaboration(RequirementDTO dto,int requirementId){
		return null;

		//return requirementElaborationDao.saveRequirementElaboration(dtoToPojoConverter.toRequirementElaboration(dto),requirementId);
	}

	@Override
	public List<RequirementElaboration> getAllRequirementElaborations() {
		
		return requirementElaborationDao.getAllRequirementElaborations();
	}

	

}
