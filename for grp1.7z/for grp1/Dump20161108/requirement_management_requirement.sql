CREATE DATABASE  IF NOT EXISTS `requirement_management` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `requirement_management`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: requirement_management
-- ------------------------------------------------------
-- Server version	5.6.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `requirement`
--

DROP TABLE IF EXISTS `requirement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requirement` (
  `requirementId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `shortTitle` varchar(10) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `version` varchar(5) DEFAULT NULL,
  `prerequisite` varchar(150) DEFAULT NULL,
  `contributorId` int(11) DEFAULT NULL,
  `parentRequirement` int(11) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `priority` varchar(45) DEFAULT NULL,
  `modifiedBy` int(11) DEFAULT NULL,
  `modifiedOn` timestamp NULL DEFAULT NULL,
  `deleted` varchar(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`requirementId`),
  UNIQUE KEY `requirement_id_UNIQUE` (`requirementId`),
  KEY `createdBy_idx` (`createdBy`),
  KEY `contributorId_idx` (`contributorId`),
  KEY `modifiedBy_idx` (`modifiedBy`),
  CONSTRAINT `contributorId` FOREIGN KEY (`contributorId`) REFERENCES `users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `createdBy` FOREIGN KEY (`createdBy`) REFERENCES `users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `modifiedBy` FOREIGN KEY (`modifiedBy`) REFERENCES `users` (`userId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requirement`
--

LOCK TABLES `requirement` WRITE;
/*!40000 ALTER TABLE `requirement` DISABLE KEYS */;
INSERT INTO `requirement` VALUES (27,'a','a','a','2016-11-03 13:06:12',1,'a','a',1,1,'a','a','a',1,'2016-11-03 13:06:12','n'),(28,'z','z','','2016-11-03 14:41:20',1,'z','z',1,1,'z','z','z',1,'2016-11-03 14:41:20','n'),(32,'q','q','q','2016-11-07 08:17:55',1,'q','q',1,1,'q','qq','q',1,'2016-11-07 08:17:55','n'),(33,'q','q','q','2016-11-07 08:20:56',1,'q','q',1,1,'q','qq','q',1,'2016-11-07 08:20:56','n'),(34,'q','q','q','2016-11-07 08:22:58',1,'q','q',1,1,'q','qq','q',1,'2016-11-07 08:22:58','n'),(35,'o','o','o','2016-11-07 08:38:21',1,'o','o',1,1,'o','o','o',1,'2016-11-07 08:38:21','n'),(36,'o','o','o','2016-11-07 08:38:57',1,'o','o',1,1,'o','o','o',1,'2016-11-07 08:38:57','n'),(37,'p','p','p','2016-11-07 08:51:35',1,'p','p',1,1,'p','p','p',1,'2016-11-07 08:51:35','n'),(38,'g','g','g','2016-11-07 09:08:25',1,'g','g',1,1,'g','g','g',1,'2016-11-07 09:08:25','n'),(39,'gds','s','d','2016-11-07 09:10:29',1,'dsg','g',1,1,'sg','gg','gg',1,'2016-11-07 09:10:29','n'),(40,'t','t','t','2016-11-07 11:57:40',1,'t','t',1,1,'t','t','t',1,'2016-11-07 11:57:40','n'),(41,'t','t','t','2016-11-07 12:56:30',1,'t','t',1,1,'t','t','t',1,'2016-11-07 12:56:30','n'),(42,'a','a','a','2016-11-07 15:52:18',1,'a','a',1,1,'a','a','a',1,'2016-11-07 15:52:18','n'),(43,'a','a','a','2016-11-07 15:53:39',1,'a','a',1,1,'','','a',1,'2016-11-07 15:53:39','n'),(44,'a','a','a','2016-11-07 15:54:43',1,'a','a',1,1,'','','a',1,'2016-11-07 15:54:43','n'),(45,'asd','asd','asd','2016-11-08 10:40:06',2,'asd','asd',2,1,'','','asd',2,'2016-11-08 10:40:06','n');
/*!40000 ALTER TABLE `requirement` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-08 17:55:32
