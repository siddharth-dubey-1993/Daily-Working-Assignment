/**
 * 
 */
package com.cybage.tester;

import com.cybage.date.Date;

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Date class objects
		Date dt1 = new Date();
		Date dt2 = new Date(02,03,2022);
		Date dt3 = new Date(13,11,2009);
		// calling displayDate method using date class objects
		dt1.displayDate();
		dt2.displayDate();
		dt3.displayDate();

	}

}
