/**
 * 
 */
package com.cybage.customer;

/**
 * @author Siddharth
 * Customer class
 */
public class Customer {
	private String name;
	private int age;
	private String address;
	
	public Customer(String name, int age, String address) {
		super();
		this.name = name;
		this.age = age;
		this.address = address;
	}
	
	// display method to display the values. 
	public void display(){
		System.out.println("Name : "+name+", Age : "+age+", Address : "+address);
	}
	
}
