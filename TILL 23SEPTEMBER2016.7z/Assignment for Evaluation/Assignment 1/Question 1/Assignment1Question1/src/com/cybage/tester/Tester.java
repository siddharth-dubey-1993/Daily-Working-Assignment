/**
 * 
 */
package com.cybage.tester;

import com.cybage.customer.Customer;

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// objects of customer class
		Customer cust1 = new Customer("Siddharth Dubey	",22,"	Kalyani Nagar");
		Customer cust2 = new Customer("Cybage		",21,"	Pune");
		Customer cust3 = new Customer("Java		",22,"	Silicon Valley");
		
		// calling display function from customer class through objects.
		cust1.display();
		cust2.display();
		cust3.display();

	}

}
