/**
 * 
 */
package com.cybage.tester;

import com.cybage.employee.Employee;

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Employee class objects
		Employee emp1 = new Employee();
		Employee emp2 = new Employee("Siddharth",22,99999.99);
		Employee emp3 = new Employee("Siddharth Dubey",22,56151.0);
		
		//calling display method through employee class objects.
		emp1.display();
		emp2.display();
		emp3.display();

	}

}
