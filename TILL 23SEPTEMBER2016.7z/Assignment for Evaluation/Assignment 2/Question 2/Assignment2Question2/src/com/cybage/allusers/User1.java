/**
 * 
 */
package com.cybage.allusers;

import com.cybage.utility.Calc;

/**
 * @author Siddharth
 * User class
 */
public class User1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Calc cal1 = new Calc();
		Calc cal2 = new Calc();
		Calc cal3 = new Calc();

		cal1.findRoot(25);
		cal2.findRoot(9);
		cal3.findRoot(11);
	}

}
