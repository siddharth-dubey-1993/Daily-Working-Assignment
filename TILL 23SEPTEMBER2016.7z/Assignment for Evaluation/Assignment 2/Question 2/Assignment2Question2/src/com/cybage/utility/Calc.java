/**
 * 
 */
package com.cybage.utility;

/**
 * @author Siddharth
 * Calc class
 */
public class Calc {
	
	public void findRoot(double value){
		double root = Math.pow(value,0.5);// Math.pow to calculate the power and 0.5 to calculate root
		System.out.println("Root of "+value+" is : "+root);
	}
}
