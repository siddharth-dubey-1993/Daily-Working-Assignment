/**
 * 
 */
package com.cybage.employee;

/**
 * @author Siddharth
 * Employee class
 */
public class Employee {
	private String employeeName;
	private int empId;
	private static int count;
	
	// default constructor
	public Employee(){
		count++;
	}
	
	//getters & setters
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		Employee.count = count;
	}
	
	
}
