/**
 * 
 */
package com.cybage.tester;

import com.cybage.employee.Employee;

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("Initial Object Count : "+Employee.getCount());
		Employee emp[] = new Employee[5];
		// iterate till the length of employee type array
		for(int i=0;i<5;i++){
			emp[i]=new Employee();
		}
		
		System.out.println("Final Object Count : "+Employee.getCount());

	}

}
