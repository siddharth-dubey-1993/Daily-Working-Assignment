/*	authored by @TUHINA and @SIDDHARTH
 * 
 * 
 * 
 * */
package workshop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class BeautySalon {
	//static ArrayList<Customer> al;

	static String m;



	public static void main(String[] args) {


		//customer data stored in array list
		ArrayList<Customer> al=new ArrayList<>();
		al.add(new Customer(101,"Tuhina", "Pune","Premium"));
		al.add(new Customer(102,"Siddharth","Delhi","Gold"));
		al.add(new Customer(103,"Vivek","Moradabad", "Silver"));
		
		//Welcome screen,asking user for guest or existing profile(menu driven)
		System.out.println("Welcome to Lakme Beauty Salon!!\n");
		System.out.println("Press 1. for existing profile\n press 2. for guest profile :\n");
		Scanner sc=new Scanner(System.in);
		int profile=sc.nextInt();
		switch(profile)
		{
		//for existing customer
		case 1:
		{
			System.out.println("Enter your customer id:");
			Scanner sc1=new Scanner(System.in);
			int id=sc.nextInt();
			
			//using iterator to match customer credentials for existing customer
			Iterator<Customer> itr = al.iterator();
			Customer c;
			while(itr.hasNext())
			{
				c=itr.next();
				if(c.getCustId()==id)
				{
					System.out.println("Welcome "+c.toString());
					m=c.getMembership();
					System.out.println("press 1. if you want a service\npress 2.if you want to buy a product\n");
					Scanner sc2=new Scanner(System.in);
					int sp=sc2.nextInt();
					
					switch(sp)
					{
					case 1:	
							Visit.service();//to calculate and display total bill for the service
							break;
					case 2:
							Visit.product();//to calculate and display total bill for the product
							break;
					default: System.out.println("wrong choice");
					}

				}


			}
		}break;
		
		//for guest user
		case 2:
		{
			System.out.println("press 1. if you want a service\npress 2.if you want to buy a product\n");
			Scanner sc2=new Scanner(System.in);
			int sp=sc2.nextInt();
			switch(sp)
			{
			case 1:	Visit.ser();//to calculate and display total bill for the service
			break;
			case 2:Visit.prod();break;//to calculate and display total bill for the product
			}break;

		

		}
		default :System.out.println("wrong choice");break;


		}
	}
}
