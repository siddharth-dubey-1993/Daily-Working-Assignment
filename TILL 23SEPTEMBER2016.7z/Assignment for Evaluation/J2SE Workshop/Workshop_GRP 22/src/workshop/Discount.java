package workshop;

public class Discount {
	
	
	static double discount;
	
	//to calculate discount on services based on customer membership
	public static double serviceDiscount(double sbill)
	{
		
		if(BeautySalon.m.equalsIgnoreCase("premium"))
			discount=sbill*0.2;
		if(BeautySalon.m.equalsIgnoreCase("gold"))
			discount=sbill*0.15;
		if(BeautySalon.m.equalsIgnoreCase("silver"))
			discount=sbill*0.1;
		return discount;
		
	}
	
	//to calculate discount on products
	public static double productDiscount(double pbill)
	{
		discount=pbill*0.1;
		return discount;
	}

}
