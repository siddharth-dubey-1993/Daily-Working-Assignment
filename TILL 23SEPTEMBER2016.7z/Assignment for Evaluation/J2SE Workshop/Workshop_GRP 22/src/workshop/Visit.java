package workshop;

import java.util.Scanner;

public class Visit {
	static int choice;
	static double d;
	static double totalBill;
	
	//to calculate and display total bill on services for existing customer
	public static void service()
	{	


		double serviceBill=0;
		
		do{
		System.out.println("select the services(s) you want to avail:\n");
		System.out.println("press 1: hair cut at Rs1000/-:\n");
		System.out.println("press 2: facial at Rs2000/-:\n");
		System.out.println("press 3: waxing at Rs500/-:\n");
		System.out.println("press 0: to exit:\n");
		
		Scanner sc3=new Scanner(System.in);
		choice=sc3.nextInt();
		switch(choice)
		{
		case 1: serviceBill+=1000;
				break;
		case 2: serviceBill+=2000;
				break;
		case 3:serviceBill+=500;
				break;
		
		case 0: break;		
		default : System.out.println("wrong choice");break;

		}
		
		
		}while(choice!=0);
		
		System.out.println("bill before discount"+serviceBill);
		d=Discount.serviceDiscount(serviceBill);
		totalBill=serviceBill-d;
		System.out.println("your total bill after discount:"+totalBill);
		



	}

	//to calculate and display total bill on product for existing customer
	public static void product()
	{	
		double productBill=0;
		do{
		
		System.out.println("select the product(s) you want to buy:\n");
		System.out.println("press 1: curler at Rs1000/-:\n");
		System.out.println("press 2: hair spray at Rs2000/-:\n");
		System.out.println("press 3: body lotion at Rs500/-:\n");
		System.out.println("press 0: to exit:\n");
		
		Scanner sc4=new Scanner(System.in);
		choice=sc4.nextInt();

		switch(choice)
		{
		case 1: productBill+=1000;
				break;
		case 2:  productBill+=2000;
					break;
		case 3:  productBill+=500;
				break;
		case 0: break;	
		default : System.out.println("wrong choice");break;
		}
		}while(choice!=0);
		System.out.println("bill before discount:"+productBill);
		d=Discount.productDiscount(productBill);
		totalBill=productBill-d;
		System.out.println("your total bill after discount:"+totalBill);
	}
	
	
	
	//to calculate and display total bill on services for guest customer
	public static void ser()
	{
		double serviceBill=0;

		do{
		System.out.println("select the services(s) you want to avail:\n");
		System.out.println("press 1: hair cut at Rs1000/-:\n");
		System.out.println("press 2: facial at Rs2000/-:\n");
		System.out.println("press 3: waxing at Rs500/-:\n");
		System.out.println("press 0: to exit");
		Scanner sc3=new Scanner(System.in);
		choice = sc3.nextInt();
		switch(choice)
		{
		case 1: serviceBill+=1000;
				break;
		case 2:serviceBill+=2000;
				break;
		case 3:serviceBill+=500;
				break;
		case 0: break;	
		default: System.out.println("wrong choice");break;
		}
		}while(choice!=0);
		System.out.println("Your total bill:"+serviceBill);
	}

	//to calculate and display total bill on products for guest customer
	public static void prod()
	{
		double productBill=0;
		do{
		System.out.println("select the product(s) you want to buy:\n");
		System.out.println("press 1: curler at Rs1000/-:\n");
		System.out.println("press 2: hair spray at Rs2000/-:\n");
		System.out.println("press 3: body lotion at Rs500/-:\n");
		
		Scanner sc4=new Scanner(System.in);
		choice=sc4.nextInt();

		switch(choice)
		{
		case 1: productBill+=1000;
		
		
		break;
		case 2:  productBill+=2000;
		
		break;
		case 3:  productBill+=500;
		
		break;
		case 0: break;	
		default : System.out.println("wrong choice");break;
		}
		}while(choice!=0);
		System.out.println("Your total bill:"+productBill);

	}
}

