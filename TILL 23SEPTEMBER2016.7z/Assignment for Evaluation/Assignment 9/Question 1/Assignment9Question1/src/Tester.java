/**
 * 
 */

/**
 * @author siddharthdu
 *
 */
public class Tester {
	public static void main(String[] args) {  
			  
		    final String resource1 = "way 1";  
		    final String resource2 = "way 2";
		   		    
		    //creating the first thread
		    Thread t1 = new Thread() {  
		    //run method	
		    public void run() {
		    	synchronized (resource1) {  //locking the resource 1(Way 1) by thread 1
		        	  						
					System.out.println("Signal => Green for WAY 1 ");
		    		  
		        	try {
						Thread.sleep(300);
					} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
		        	 
		  
		        synchronized (resource2) {  
		        
					System.out.println("Signal => Orange for WAY 1"); 
		            for(int i=0;i<10;i++)
		        	   {
		        		   if(i==7){
		        			   System.out.println("Signal => Green for WAY 1");
		        		   }
		        		   else if(i==9){
		        			   System.out.println("Signal => RED for WAY 1");
		        		   }
							try {
								Thread.sleep(300);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
		        	   }
		           } 
		         }  
		      }  
		    };  
		  
		    //creating thread2  
		    Thread t2 = new Thread() {  
		      public void run() {  //run method
		        synchronized (resource1) {  //locking the resource 2(Way 2) by thread 2
		        	System.out.println("Signal => Green for WAY 2 ");
		  
		          try {
						Thread.sleep(300);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		  
		          synchronized (resource2) {  
		        	  System.out.println("Signal => Orange for WAY 2"); 
			            for(int i=0;i<10;i++)
			        	   {
			            	if(i==7){
			        			   System.out.println("Signal => Green for WAY 2");
			        		   }
			        		   else if(i==9){
			        			   System.out.println("Signal => RED for WAY 2");
			        		   }
			        		   try {
									Thread.sleep(300);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
			        	   }
			            
			           } 
			           
		        }  
		      }  
		    };  
		    //creating new thread
		    t1.start();  
		    t2.start();
	}
}
