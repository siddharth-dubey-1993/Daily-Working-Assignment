
/**
 * @author siddharthdu
 *	Member class
 */
public class Member extends Thread{
	
	private Account a;
	private double money;
	// constructor
	public Member(String name, Account a, double money) {
		super(name);
		this.a = a;
		this.money = money;
	}
	
	// thread task
	public void run() {
		
		System.out.println(Thread.currentThread().getName() + " Transaction in Progress");
		
		synchronized(a)
		{
			a.transact(money);
		}
	}
}
