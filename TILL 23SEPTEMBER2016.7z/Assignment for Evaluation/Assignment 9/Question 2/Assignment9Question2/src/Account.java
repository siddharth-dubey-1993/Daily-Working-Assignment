
/**
 * @author siddharthdu
 *	Account Class
 */
public class Account {
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", balance=" + balance + "]";
	}

	private int accNo;
	private double balance;
	
	public Account(int accNo, double balance) {
		this.accNo = accNo;
		this.balance = balance;
		}
	
	public void deposit(double money) {
		
		balance = balance+ money;
		System.out.println("Amount Deposited");
	}
	
	public void transact(double money) {
		
		if(money < balance)
		{
			balance = balance - money;
			System.out.println(Thread.currentThread().getName() + " Amount successfully withdrawn");
		}
		else
			System.out.println(Thread.currentThread().getName() + " Balance not enough");
	}
	
}

