/**
 * @author siddharthdu
 * 
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Account class Object
		Account acc1 = new Account(5645622, 5000);
				
		//Member class object to withdraw ammount
		Member m1 = new Member("Siddharth", acc1, 590.0);
		Member m2 = new Member("Tuhina", acc1, 25897.0);
				
		m2.start();
		m1.start();
	}

}
