/**
 * 
 */
package com.cybage.tester;

import com.cybage.account.BankAccount;
import com.cybage.account.Current;
import com.cybage.account.Saving;

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		String s1 = "Saving";
		String s2 = "Current";
		String s3 = args[0];
		BankAccount ba = null; // BankAccount class object referencing to null. 
		// equating s1 with s2 
		if(s1.equalsIgnoreCase(s3)){
			ba = new Saving(); 
			System.out.println("Rate of Interest for Saving Account is "+ba.roiDisplay()+"% per year.");
		}
		// equating s2 with s3
		else if(s2.equalsIgnoreCase(s3)){
			ba = new Current();
			System.out.println("Rate of Interest for Current Account is "+ba.roiDisplay()+"% per year.");
		}
		else{
			System.out.println("Invalid Arguments Passed.");
			System.out.println("Rate of Interest for Saving Account is 9.3% per year.");
			System.out.println("Rate of Interest for Current Account is 4.9% per year.");
		}
		
		
		
	}

}
