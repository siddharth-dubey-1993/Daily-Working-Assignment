/**
 * 
 */
package com.cybage.account;

/**
 * @author Siddharth
 * Current Account Class
 */
public class Current extends BankAccount {
	// roi for current account
	private double roi = 4.9;

	public double roiDisplay(){
		return roi;
	}

	
}
