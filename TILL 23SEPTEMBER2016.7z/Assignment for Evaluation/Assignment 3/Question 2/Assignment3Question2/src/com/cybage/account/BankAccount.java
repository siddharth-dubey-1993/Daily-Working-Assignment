/**
 * 
 */
package com.cybage.account;

/**
 * @author Siddharth
 * Bank Account class
 */
public abstract class BankAccount {
	abstract public double roiDisplay(); // abstract roi method which will be implementd in the child class.
	
			
}
