/**
 * 
 */
package com.cybage.account;

/**
 * @author Siddharth
 * Saving account class
 */
public class Saving extends BankAccount {
	// roi for saving account
	private double roi = 9.3;

	public double roiDisplay(){
		return roi;
	}
	
	
}
