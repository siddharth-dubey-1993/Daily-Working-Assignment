import java.util.Calendar;

/**
 * 
 */

/**
 * @author Siddharth
 *
 */
public class Patient extends Person {
	private int patientNum;
	private int hospitalId;
	private int hospitalJoiningYear;
	private String hospitalName;
	private String patientAddress;
	private double medicalFees;
	//constructor
	public Patient(String name, int age, String bloodGroup, double height, double weight, int patientNum)
	{
		super(name, age, bloodGroup, height, weight);
		this.patientNum = patientNum;
		this.medicalFees = 0.0;
	}
	//getter & setters
	public int getPatientNum() {
		return patientNum;
	}

	public void setPatientNum(int patientNum) {
		this.patientNum = patientNum;
	}

	public int getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}
	public int getHospitalJoiningYear() {
		return hospitalJoiningYear;
	}
	public void setHospitalJoiningYear(int hospitalJoiningYear) {
		this.hospitalJoiningYear = hospitalJoiningYear;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getPatientAddress() {
		return patientAddress;
	}
	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}
	
	public double getMedicalFees() {
		return medicalFees;
	}
	// passing money object to set medical fees
	public void setMedicalFees(Money mon) {
		medicalFees = medicalFeesCal(mon);
	}
	//method to calculate the medical fees
	private double medicalFeesCal(Money mon){
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);// to get the current year.
		// returning (no of years in hospital * medical fees per year).
		return ((currentYear-getHospitalJoiningYear())*(mon.basicFeePerYear));
	}
	// display method to display the details.
	public void display(){
		System.out.println("Name : "+getName());
		System.out.println("Age : "+getAge());
		System.out.println("Blood Group : "+getBloodGroup());
		System.out.println("Height : "+getHeight());
		System.out.println("Weight : "+getWeight());
		System.out.println("Patient Number : "+getPatientNum());
		System.out.println("Hospital Id : "+getHospitalId());
		System.out.println("Hospital Name : "+getHospitalName());
		System.out.println("Patient Address : "+getPatientAddress());
		System.out.println("Hospital Joining Year : "+getHospitalJoiningYear());
		System.out.println("Medical Fees : "+getMedicalFees());
		
	}

}
