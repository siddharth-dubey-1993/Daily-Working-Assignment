/**
 * 
 */

/**
 * @author Siddharth
 * Money class whose object will be passed to calculate the medical fees.
 */
public class Money {
	double basicFeePerYear = 1200.50;
}
