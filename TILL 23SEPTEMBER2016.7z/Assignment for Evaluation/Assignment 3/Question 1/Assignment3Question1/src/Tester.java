/**
 * 
 */

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Please enter the details :");
		//Person per1 = new Person();
		Money mon = new Money();
		Patient pat1 = new Patient("Kunal Dubey", 23, "B -ve", 5.5, 60, 001);
		pat1.setHospitalJoiningYear(2010);
		pat1.setHospitalId(77);
		pat1.setHospitalName("Medipoint Hospital");
		pat1.setPatientAddress("Wireless Colony, DP Road, Aundh, Pune.");
		pat1.setMedicalFees(mon); // passing money class object to set per year fees
		
		pat1.display(); // display method to display details
	}

}
