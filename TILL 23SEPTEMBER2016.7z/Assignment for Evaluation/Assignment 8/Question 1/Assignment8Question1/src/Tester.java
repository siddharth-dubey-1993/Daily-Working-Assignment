/**
 * 
 */

/**
 * @author siddharthdu
 *
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Tester {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			 // input from user
			PrintWriter pw1 = new PrintWriter(System.out,true);
			pw1.println("Please enter the data ");
			BufferedReader br1= new BufferedReader(new InputStreamReader(System.in));
			String name = br1.readLine();
			// file creation
			File file1=new File("firstFile.txt");
			BufferedWriter bw1=new BufferedWriter(new FileWriter(file1));
			bw1.write(name);
			bw1.close();
			// taking input from file
			String str1=null;
			BufferedReader br2=new BufferedReader(new FileReader("firstFile.txt"));
			str1=br2.readLine();
			pw1.println(str1);
			br2.close();
			// copy data from first file to second file
			File file2=new File("secondFile.txt");
			BufferedWriter bw2=new BufferedWriter(new FileWriter(file2));
			bw2.write(str1);
			bw2.close();
			// display file content on console
			BufferedReader br3=new BufferedReader(new FileReader(file2));
			String file3=br3.readLine();
			pw1.println(file3);
			br3.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
