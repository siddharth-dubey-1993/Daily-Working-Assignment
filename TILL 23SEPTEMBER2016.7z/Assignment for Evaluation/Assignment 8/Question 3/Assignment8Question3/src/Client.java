/**
 *  Client class
 */

/**
 * @author siddharthdu
 *
 */
import java.io.IOException;
import java.io.DataOutputStream;
import java.util.Scanner;
import java.io.DataInputStream;
import java.net.Socket;
import java.io.EOFException;

public class Client {
	public static void main(String[] args) {
		int portNumber = 4568; //port number on which communication will happen.
		String webServer = "127.0.0.1"; // address of the  server
		
		try {
			
			Scanner sc = new Scanner(System.in);
			// trying connect to the server.
			Socket client = new Socket(webServer, portNumber);
			System.out.println("Connection Successful " + client.getRemoteSocketAddress());
			System.out.println("Please wait Server unavailable");
			String str1 = new String();
			boolean isDown = false;
			DataInputStream d1 = new DataInputStream(client.getInputStream());
			DataOutputStream d2 = new DataOutputStream(client.getOutputStream());
			
			while (!isDown) {
				System.out.println("Web Server : " + d1.readUTF());
				System.out.println("Type KILL_CHAT to end otherwise enter the Message");
				String str2 = sc.nextLine();

				
				if (str2.equals("KILL_CHAT")) {
					isDown = true;
				}
				d2.writeUTF(str1);
				System.out.println("Web Server : " + d1.readUTF());

			} 
			client.close();
			sc.close();
		}
		catch (EOFException e) {
			System.out.println(e.getMessage());
			System.err.println(e);
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
