/**
 * Server class
 */

/**
 * @author siddharthdu
 *
 */

import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;
import java.net.ServerSocket;
import java.io.DataInputStream;
import java.io.IOException;

public class Server {
	public static void main(String[] args) {
		int port = 4568; //port number on which communication will happen.
		boolean isDown = false; // to check whether the server is live or not
		String str1 = new String();
		
		
		try {
			ServerSocket socket1 = new ServerSocket(port);
			System.out.println("Server connected");
			Socket webServer = socket1.accept();
			System.out.println("Connection Successful");
			System.out.println("IP:" + webServer.getInetAddress());
				
			DataInputStream di1 = new DataInputStream(webServer.getInputStream());
			DataOutputStream do1 = new DataOutputStream(webServer.getOutputStream());
			
			
			Scanner sc = new Scanner(System.in);
			
			while (!isDown) {
				System.out.println("Type KILL_CHAT to end otherwise enter the Message");
				if (sc.hasNextLine())
					str1 = sc.nextLine();
				
				if (str1.equals("KILL_CHAT")) {
					isDown = true;
					break;
				}
				do1.writeUTF(str1);

				System.out.println("Client : " + di1.readUTF());

			}
			sc.close();
			socket1.close();
			webServer.close();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

}