package account;

/**
 * Account Class 
 */

/**
 * @author siddharthdu
 *
 */

import java.util.Date;
import java.io.Serializable;

public class Account implements Serializable {

	private String name;
	private transient int pincode;
	private Date doc;
	private int acctNo;
	
	// Parameterized Constructor
	public Account(int acctNo, String name, int pincode) {
		super();
		this.name = name;
		this.pincode = pincode;
		this.doc = new Date();
		this.acctNo = acctNo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Acc. No. = " + acctNo + "\n Name =" + name + "\n Date of Creation=" + doc+ "\n PinCode=" + pincode ;
	}
	
	
}
