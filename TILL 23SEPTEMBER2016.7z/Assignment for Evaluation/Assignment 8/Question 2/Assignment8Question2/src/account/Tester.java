/**
 * Tester  
 */

/**
 * @author siddharthdu
 *
 */
package account;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class Tester {

	public static void main(String[] args) {
		

        //Creating Account Object
		Account acnt=new Account(100, "Siddharth", 101001);
		try {
			
			// For Serializing Account Object
			ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream("Account.txt"));
			out.writeObject(acnt);
			System.out.println("Account object => ");
			System.out.println(acnt);
			out.close();

			// For Deserializing Account Object 
			ObjectInputStream in=new ObjectInputStream(new FileInputStream("Account.txt"));
			Account acnt1=(Account)in.readObject();
			System.out.println("Object after deserialization => ");
			System.out.println(acnt1);
			in.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
