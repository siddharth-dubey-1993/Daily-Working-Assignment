/**
 * 
 */
package com.cybage.tester;

/**
 * @author siddharthdu
 *	class to insert and update record in database
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.cybage.util.DBConnection;

public class Tester {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Connection conn = DBConnection.getConnection();
		
		try{
			//inserting record in database
			PreparedStatement ps1 = conn.prepareStatement("insert into employee values (?,?,?)");
			ps1.setInt(1, 1);  
			ps1.setString(2, "Siddharth");
			ps1.setDouble(3, 3330.0);  
			
			ps1.executeUpdate();
			System.out.println("Record Inserted");
			ps1.close();
			
			//update record in database
			PreparedStatement ps2 = conn.prepareStatement("update employee set ename = ? where eid = ?");
			ps2.setString(1, "Tuhina");
			ps2.setDouble(2, 532.2);
			
			ps2.executeUpdate();
			System.out.println("Recored Updated");
			ps2.close();
			conn.close(); //closing connection
		}
		catch(SQLException e) {
			
			System.out.println(e);
		}
		

	}

}
