/**
 * 
 */
package com.cybage.tester;


/**
 * @author siddharthdu
 *	class to execute the stored procedure
 */

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.cybage.util.DBConnection;

public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Connection conn;
			conn = DBConnection.getConnection();
			CallableStatement cstmt;
			cstmt=conn.prepareCall("{call NewSalary()}");  // stored procedure    
			cstmt.execute();  
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
