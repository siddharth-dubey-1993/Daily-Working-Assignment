/**
 * 
 */

/**
 * @author Siddharth
 *
 */
public class tester {

	public static void main(String[] args) {
		dummy d1 = new dummy();
		dummy d2 = new dummy();
		dummy d3 = new dummy();
		String s1;
		String s2;
		
		System.out.println("Memory before running GC :"+Runtime.getRuntime().freeMemory());
		System.gc(); // calling garbage collector.		
		System.out.println("Memory after running GC :"+Runtime.getRuntime().freeMemory());
		
		
		
		

	}

}
