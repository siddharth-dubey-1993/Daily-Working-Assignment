/**
 * 
 */

/**
 * @author Siddharth
 *	Dummy class
 */
public class dummy {
	int x = 10;
}
