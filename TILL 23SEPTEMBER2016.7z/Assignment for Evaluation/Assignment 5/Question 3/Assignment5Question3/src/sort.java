/**
 * 
 */

/**
 * @author Siddharth
 * sort class
 */
public class sort {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int length1 = args.length; // finding the no of command line arguments beings passed & storing it.
		int arr []= new int[length1]; // creating an array of size equal to no of command line arguments passed. 
		
		for(int i=0 ; i<length1 ; i++){
			arr[i] = Integer.parseInt(args[i]); // converting string type command line arguments to integer type and storing it in an array.
		}
		
		System.out.println("Numbers before sorting ");
		for(int i=0; i<arr.length ; i++){
			System.out.print(arr[i]+" ");
		}
		// sorting logic
		for(int i=0 ; i<arr.length ; i++){
			for(int j=0 ; j<arr.length ; j++){
				if(arr[i]<arr[j]){
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}	
		}
		
		System.out.println();
		System.out.println("Numbers after sorting in ascending order ");
		for(int i = 0; i<arr.length ; i++){
			System.out.print(arr[i]+" ");
		}
		
		System.out.println();
		System.out.println("Numbers after sorting in descending order ");
		for(int i = arr.length-1; i>=0 ; i--){
			System.out.print(arr[i]+" ");
		}
		
	}

}
