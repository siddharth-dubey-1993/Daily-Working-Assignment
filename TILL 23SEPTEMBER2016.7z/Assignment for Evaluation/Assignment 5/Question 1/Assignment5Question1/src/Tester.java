/**
 * 
 */

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee emp1 = new Employee("Siddharth",16721,"Engineering",100000.78);
		Employee emp2 = new Employee("Kunal",685,"QA",5566.05);
		Employee emp3 = new Employee("Siddharth",16721,"Engineering",100000.78);
		
		Account acc1 = new Account(5866,"Savings",800095,6.3);
		Account acc2 = new Account(5866,"Savings",800095,6.3);
		Account acc3 = new Account(5866,"Current",55080,9.9);
		
		if(emp1.equals(emp2)){
			System.out.println("emp1 & emp2 are equal");
		}
		else{
			System.out.println("emp1 & emp2 are unequal");
		}
		if(emp1.equals(emp3)){
			System.out.println("emp1 & emp3 are equal");
		}
		else{
			System.out.println("emp1 & emp3 are unequal");
		}
		
		if(acc1.equals(acc2)){
			System.out.println("acc1 & acc2 are equal");
		}
		else{
			System.out.println("acc1 & acc2 are unequal");
		}
		if(acc1.equals(acc3)){
			System.out.println("acc1 & acc3 are equal");
		}
		else{
			System.out.println("acc1 & acc3 are unequal");
		}

	}

}
