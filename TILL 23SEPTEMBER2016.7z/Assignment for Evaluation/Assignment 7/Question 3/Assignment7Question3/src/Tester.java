import java.util.HashMap;
import java.util.Iterator;

/**
 * 
 */

/**
 * @author siddharthdu
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HashMap<Book,Integer> hsmap = new HashMap<>(); 
		// collection to store object of book type where Object of book is Key and No of Page is value
		hsmap.put(new Book(123, "The Theory Of Everything", "Stephen Hawkins"),1222);
		hsmap.put(new Book(223, "Brief History Of Time", "Albert Einstein"),1552);
		hsmap.put(new Book(1234, "The Theory Of Computation", "Aho Ullman"),856);
		hsmap.put(new Book(243, "Man Who Sold His Ferari", "Robin Sharma"),250);
		
		Iterator i = hsmap.keySet().iterator(); // iterator to iterate over the collection.
		for(;(i.hasNext());) // to print the hash map 
		{
			Book b= (Book) i.next();
			Integer v=(Integer)hsmap.get(b);
			System.out.println(" Book : "+b+" Page : "+v);
		}
	}
}