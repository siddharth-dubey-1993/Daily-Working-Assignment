
/**
 * Tester class
 */

/**
 * @author siddharthdu
 *
 */
 
import java.util.ArrayList;
import java.util.Iterator;

public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList<Person> al = new ArrayList<Person>(); // array list to store the objects.
		al.add(new Patient("Siddharth", 22, 1010, "Kalyani nagar", 8080, "MediPoint", "Fever"));
		al.add(new Patient("Tuhina", 23, 1011, "Kalyani nagar", 8080, "MediPoint", "Headache"));
		al.add(new Patient("Nagpal", 25, 1012, "Vishal Nagar", 8082, "AIIMS", "Snake Bite"));
		al.add(new Patient("Pranjal", 22, 1014, "Kalyani nagar", 8080, "MediPoint", "Hair Loss"));
		al.add(new Patient("Sumit", 29, 1015, "Kalyani nagar", 8080, "MediPoint", "Mental Imbalance"));
		
		//switching on basis of command line input
		switch(Integer.parseInt(args[0])){
		case 1:
			// add new record
			al.add(new Patient("Maitri", 23, 1016, "Aundh", 8082, "AIIMS", "GAS"));
			for (Person person : al) {
				System.out.println(person);
			}
			break;
		
		case 2:
			// update record (disease)
			Iterator<Person> itr = al.iterator(); //  to iterate over the array list
			Patient pat=null;
			while(itr.hasNext())
			{
				pat=(Patient) itr.next();
				if(pat.getPatientId()==1010)
				{
					pat.setDisease("No Disease");
					break;
				}
			}
			System.out.println(pat);
			System.out.println("Record Updated");
			for (Person person : al) {
				System.out.println(person);
			}
			break;
			
		
		case 3:
			// record removal
			System.out.println("Patient "+al.get(2)+" removed.");
			al.remove(2);
			break;
			
		case 4:
			// size of records
			System.out.println("Size of records created : "+al.size());
			break;
		
		// default case 
		default: System.out.println("Invalid input");	
		break;
		}	
	}

}
