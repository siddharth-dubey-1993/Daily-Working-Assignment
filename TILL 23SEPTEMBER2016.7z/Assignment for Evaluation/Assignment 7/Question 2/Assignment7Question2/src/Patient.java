/**
 * Patient class extending the Person class
 */

/**
 * @author siddharthdu
 *
 */
public class Patient extends Person {
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", name=" + name + ", age=" + age + " patientAddress=" + patientAddress + ", hospitalId=" + hospitalId
				+ ", hospitalName=" + hospitalName + ", disease=" + disease + ",]";
	}

	int patientId;
	String patientAddress;
	int hospitalId;
	String hospitalName;
	String disease;
	
	// constructor
	public Patient(String name, int age, int patientId, String patientAddress, int hospitalId, String hospitalName,
			String disease) {
		super(name, age);
		this.patientId = patientId;
		this.patientAddress = patientAddress;
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.disease = disease;
	}
	
	/**
	 * @return the patientId
	 */
	public int getPatientId() {
		return patientId;
	}

	
	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	/**
	 * @return the patientAddress
	 */
	public String getPatientAddress() {
		return patientAddress;
	}

	/**
	 * @param patientAddress the patientAddress to set
	 */
	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}

	/**
	 * @return the hospitalId
	 */
	public int getHospitalId() {
		return hospitalId;
	}

	/**
	 * @param hospitalId the hospitalId to set
	 */
	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	/**
	 * @return the hospitalName
	 */
	public String getHospitalName() {
		return hospitalName;
	}

	/**
	 * @param hospitalName the hospitalName to set
	 */
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	/**
	 * @return the disease
	 */
	public String getDisease() {
		return disease;
	}

	/**
	 * @param disease the disease to set
	 */
	public void setDisease(String disease) {
		this.disease = disease;
	}
	
	
}
