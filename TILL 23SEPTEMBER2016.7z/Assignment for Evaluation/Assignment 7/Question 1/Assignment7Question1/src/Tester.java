import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

/**
 * 
 */

/**
 * @author siddharthdu
 *
 */
public class Tester {

	/**
	 * @param args
	 */
public static void main(String[] args) {
		
		HashSet<Employee> ss=new HashSet<>(); 
		// collection to store the employee objects.
		ss.add(new Employee(1557,"Kunal Dubey"));
		ss.add(new Employee(134,"Kunal Dubey"));
		ss.add(new Employee(587,"Yatesh Mathuriya"));
		ss.add(new Employee(1565,"Mita Ghosh"));
		ss.add(new Employee(6357,"Shreekar Tare"));

		ArrayList<Employee> al=new ArrayList<>(ss);
		Collections.sort(al); // sorting the array list
		System.out.println(al);
		
	}


}
