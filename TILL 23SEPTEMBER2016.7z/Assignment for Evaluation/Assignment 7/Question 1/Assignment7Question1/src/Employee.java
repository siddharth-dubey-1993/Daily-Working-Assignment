/**
 * @author siddharthdu
 *
 */
public class Employee implements Comparable<Employee> {
	int empId;
	String empName;
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}
	
	// constructor
	public Employee(int i, String string) {
		empId=i;
		empName=string;
	}
	
	// overridden compareTo for sorting Employee type Object
	@Override
	public int compareTo(Employee o) {
		if(this.empId>o.empId)
			return 1;
			if(this.empId<o.empId)
				return -1;
			else
				return 0;
	}

}
