/**
 * 
 */
package com.cybage.jetengine;

/**
 * @author siddharthdu
 *
 */
public class DebrisInEngineException extends RuntimeException {
	public DebrisInEngineException(String s) {
		super(s);
	}
}
