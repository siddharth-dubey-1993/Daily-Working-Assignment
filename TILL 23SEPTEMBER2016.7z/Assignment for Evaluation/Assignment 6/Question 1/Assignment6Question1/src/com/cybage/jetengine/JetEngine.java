/**
 * 
 */
package com.cybage.jetengine;

/**
 * @author siddharthdu
 *
 */
public class JetEngine {
	
	/**
	 * @param args
	 */
	double fuel;
	double weight;
	double workingHours;
		
	public JetEngine(double fuel, double weight, double workingHours) {
		super();
		this.fuel = fuel;
		this.weight = weight;
		this.workingHours = workingHours;
	}
	//Start method to start engine.
	public void start(){
		System.out.println("Jet Engine Started ..........");
		execute();
	}
	// execute method to execute engine.
	public void execute() throws OutOfFuelException,DebrisInEngineException,MaintainanceDueException{
		try{
			if(fuel<10){
				throw new OutOfFuelException("\n Engine is running out of fuel. Switching Off Engine");
			}
			else if(!(weight==1500)){
				throw new DebrisInEngineException("\n Debris in Engine. Switching Off Engine");
			}
			else if(workingHours > 1000){
				throw new MaintainanceDueException("\n Engine Maintenance is due. Please ensure the Engine is serviced soon.");
			}
			else{
				System.out.println("  Jet Engine Running................");
			}
		}
		catch(OutOfFuelException e)
		{
			System.out.println(e);
			stop();
		}
		catch(DebrisInEngineException e)
		{
			System.out.println(e);
			stop();
		}
		catch(MaintainanceDueException e)
		{
			System.out.println(e);
			stop();
		}
	}
	//stop method to stop engine.
	public void stop(){
		System.out.println("Jet Engine Stopped.................\n\n\n");
		
	}
}
