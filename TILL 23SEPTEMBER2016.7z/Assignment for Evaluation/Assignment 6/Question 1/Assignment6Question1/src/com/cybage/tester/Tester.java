/**
 * 
 */
package com.cybage.tester;

import com.cybage.jetengine.JetEngine;

/**
 * @author siddharthdu
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JetEngine je1 = new JetEngine(9999,1500,100);
		je1.start();
		JetEngine je2 = new JetEngine(99,2000,67);
		je2.start();
		JetEngine je3 = new JetEngine(9,1000,67);
		je3.start();
		JetEngine je4 = new JetEngine(99,1000,6857);
		je4.start();

	}

}
