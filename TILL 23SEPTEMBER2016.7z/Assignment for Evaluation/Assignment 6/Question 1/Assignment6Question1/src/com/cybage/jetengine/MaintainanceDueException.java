/**
 * 
 */
package com.cybage.jetengine;

/**
 * @author siddharthdu
 *
 */
public class MaintainanceDueException extends RuntimeException {
	public MaintainanceDueException(String s) {
		super(s);
	}
}
