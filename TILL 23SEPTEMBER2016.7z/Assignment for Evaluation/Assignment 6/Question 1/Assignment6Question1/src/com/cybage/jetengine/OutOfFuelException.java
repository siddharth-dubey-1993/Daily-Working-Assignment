/**
 * 
 */
package com.cybage.jetengine;

/**
 * @author siddharthdu
 *
 */
public class OutOfFuelException extends RuntimeException {
	public OutOfFuelException(String s) {
		super(s);
	}
}