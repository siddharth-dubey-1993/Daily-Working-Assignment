/* @Author : Siddharth Dubey */

// Insufficient Balance Exception class
public class InsufficientBalanceException extends RuntimeException {
	public InsufficientBalanceException(String s) {
		super(s);
	}
}
