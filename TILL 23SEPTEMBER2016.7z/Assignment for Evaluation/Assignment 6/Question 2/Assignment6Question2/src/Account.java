/* @Author : Siddharth Dubey */

// Account class
public class Account {
	double balance = 8899.25; // initial account balance

	public void transaction(double amount) throws InsufficientBalanceException {
		System.out.println("Balance : " + balance + "\n");
		try {
			// checking whether the amount to be withdrawn is valid or not
			if (amount > balance)
				throw new InsufficientBalanceException("\nSorry Insufficient Balance.");
			else {
				System.out.println("Transaction Successfull. ");
				balance = balance - amount;
				System.out.println("Amount Withdrawn : " + amount);
				System.out.println("Remaining Balance : " + balance);
				System.out.println();

			}
		} catch (InsufficientBalanceException e) {
			System.out.println(e);
		}

	}
	// main
	public static void main(String[] args) {
		// Account class objects
		Account a = new Account();
		a.transaction(500);// passing the amount to be withdrawn.
		a.transaction(1000);
		a.transaction(5000);
		a.transaction(80000);
	}

}
