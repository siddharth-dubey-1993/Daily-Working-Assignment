/**
 * 
 */

/**
 * @author Siddharth
 * Printable interface
 */
public interface Printable {
	public void print();
	
}
