/**
 * 
 */

/**
 * @author siddharthdu
 *
 */
public class Tester {
	public static void main(String args[]){
		Shape s1 = new Shape();
		Animal a1 = new Animal();
		a1.print();
		s1.print();
	}
}
