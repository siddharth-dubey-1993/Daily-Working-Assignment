/**
 * 
 */

/**
 * @author siddharthdu
 * Shape class
 */
public class Shape implements Printable{
	// concerete method for printable interface
	public void print(){
		System.out.println("Shape");
	}

}
