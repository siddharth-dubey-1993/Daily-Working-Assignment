/* 26 Aug 2016 */

/**
 * @author Siddharth
 * 26 Aug 2016
 * Vehicle class
 */
public class Vehicle {
	
	public void move(){
		System.out.println(" Vehicle moving.");
	}

}
