/**
 * 
 */

/**
 * @author Siddharth
 * Motorbike class
 */
public class Motorbike extends Vehicle {
	public void move(){
		System.out.println("	MotorBike moving.");
	}
}
