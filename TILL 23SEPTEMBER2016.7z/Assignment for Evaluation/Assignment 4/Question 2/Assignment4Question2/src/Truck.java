/**
 * 
 */

/**
 * @author Siddharth
 * Truck class
 */
public class Truck extends Vehicle{
	public void move(){
		System.out.println("	Truck moving.");
	}
}
