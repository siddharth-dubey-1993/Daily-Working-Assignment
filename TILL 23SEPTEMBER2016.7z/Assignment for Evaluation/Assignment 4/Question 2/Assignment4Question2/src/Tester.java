/**
 * 
 */

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// creating array of references
		Vehicle veh[]= new Vehicle[10];
		// storing objects in vehicle type array	
		for(int i=0;i<10;i++)
		{
			if(i==1||i==3||i==7)
			{
				veh[i]=new Motorbike();
			}
			else if(i==2||i==4||i==5)
			{
				veh[i]=new Car();
			}
			else
			{
				veh[i]=new Truck();
			}
			// calling move method based on object
			veh[i].move();
			
		}
	}	

}

	