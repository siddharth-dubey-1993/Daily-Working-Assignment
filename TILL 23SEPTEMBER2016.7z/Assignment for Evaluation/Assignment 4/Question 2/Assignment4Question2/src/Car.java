/**
 * 
 */

/**
 * @author Siddharth
 * Car class
 */
public class Car extends Vehicle {
	public void move(){
		System.out.println("	CAR moving.");
	}
}
