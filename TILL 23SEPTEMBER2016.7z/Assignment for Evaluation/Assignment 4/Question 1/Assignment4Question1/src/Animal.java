/* 26 Aug 2016 */

/**
 * @author Siddharth
 * 26 Aug 2016
 * Animal class
 */
public class Animal {
	// respirate method
	public void respirate(){
		System.out.println("ANIMAL Look I am respiring.");
	}
	// talk method
	public void talk(){
		System.out.println("Since when animals started talking ?");
	}

}
