/**
 * 
 */

/**
 * @author Siddharth
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Animal anim[]= new Animal[10];
		// assigning memory locations to object in array.	
		for(int i=0;i<10;i++)
		{
			if(i==1||i==3||i==7)
			{
				anim[i]=new Dog();
			}
			else if(i==2||i==4||i==5)
			{
				anim[i]=new Cat();
			}
			else
			{
				anim[i]=new Lion();
			}
			// calling the animal/lion/cat/dog class respitae and talk methos
			anim[i].respirate();
			anim[i].talk();
			
		}
	}	

}

	