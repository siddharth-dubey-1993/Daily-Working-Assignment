/**
 * 
 */

/**
 * @author Siddharth
 * Cat class
 */
public class Cat extends Animal {
	public void talk(){
		System.out.println("	CAT Meow Meow Meow.");
	}
}
