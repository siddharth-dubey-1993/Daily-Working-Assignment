/**
 * 
 */

/**
 * @author Siddharth
 * Lion class
 */
public class Lion extends Animal{
	public void talk(){
		System.out.println("	LION Roar Roar Roar.");
	}
}
