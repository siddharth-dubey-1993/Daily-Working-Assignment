/**
 * 
 */

/**
 * @author Siddharth
 * Dog class
 */
public class Dog extends Animal {
	public void talk(){
		System.out.println("	DOG Woff Woff Woff");
	}
}
