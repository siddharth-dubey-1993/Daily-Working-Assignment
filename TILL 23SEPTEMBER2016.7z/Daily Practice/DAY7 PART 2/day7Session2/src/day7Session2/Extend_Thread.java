package day7Session2;

public class Extend_Thread extends Thread {

	public void run()
	{
		System.out.println("Thread is running");
	}
	
	public static void main(String[] args) {
		
		Extend_Thread et=new Extend_Thread();
		Thread t=new Thread(et,"et");
		//System.out.println("Thread is born");
		System.out.println(t.getState());
		t.start();
		System.out.println(t.getState());
	}
}
