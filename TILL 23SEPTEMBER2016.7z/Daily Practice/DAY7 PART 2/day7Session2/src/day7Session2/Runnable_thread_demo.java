/**
 * 
 */
package day7Session2;


public class Runnable_thread_demo implements Runnable {

	public void run(){
		try{
			
			for(int i=0;i<5;i++)
			{
				if(i==3){
					Thread.sleep(1000);
				}
				else{
					System.out.println(Thread.currentThread()+" Thread is Running");
				}
			}
			
		}
		catch(InterruptedException ie){
			System.out.println(ie);
		}
	}


	public static void main(String[] args) {
		
		Runnable_thread_demo rtd = new Runnable_thread_demo();
		Thread t = new Thread(rtd,"m1");
		t.start();
		t.run();
		
	}

}
