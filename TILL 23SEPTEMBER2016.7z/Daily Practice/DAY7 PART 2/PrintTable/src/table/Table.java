package table;

public class Table extends Thread {

	
	public Table(int a) {
		super();
		this.a = a;
	}
	int a=0;
	
	public void run()
	{
		for(int i=1;i<11;i++)
		{
			if(i==4)
				{
				Thread.yield();
				System.out.println("Thread is alive");
				}
			System.out.println( a+"*"+i+"="+i*a);
		}
	}
}
