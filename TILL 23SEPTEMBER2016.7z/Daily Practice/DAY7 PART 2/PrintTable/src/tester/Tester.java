package tester;

import table.Table;

public class Tester {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		Table t1=new Table(5);
		Thread th1=new Thread(t1);
		Table t2=new Table(8);
		Thread th2=new Thread(t2);
	
		System.out.println("Is alive "+th1.isAlive());
		th1.start();
		th1.join();
		System.out.println("Is alive "+th1.isAlive());
		
		System.out.println("Is alive "+th2.isAlive());
		th2.start();
		System.out.println("Is alive "+th2.isAlive());
		System.out.println("exit");
	}

}
