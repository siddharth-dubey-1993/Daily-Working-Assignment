/**
 * 
 */

/**
 * @author siddharthdu
 *
 */
public class StringLength {

	/**
	 * @param args
	 */
	static String str1 = "Siddharth";
	static String str2 = "Vivek";
	public static void StringCompare() {
		// TODO Auto-generated method stub
		if(str1.length()==str2.length()){
			System.out.println("equal");
		}
		else{
			System.out.println("not equal");
		}
	}
	
}
