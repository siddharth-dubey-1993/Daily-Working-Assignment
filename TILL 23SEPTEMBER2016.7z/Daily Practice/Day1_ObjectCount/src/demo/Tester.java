/* Code for printing the number of Objects. */

package demo;
import demo.Dummy;
public class Tester {

	public static void main(String[] args) {
		
		//Initial object count.
		System.out.println("Initial Object Count: "+Dummy.count);
		Dummy D1= new Dummy();
		Dummy D2= new Dummy();
		Dummy D3= new Dummy();
		//Final object count.
		System.out.println("Final Object Count: "+Dummy.count);
		
	}

}
