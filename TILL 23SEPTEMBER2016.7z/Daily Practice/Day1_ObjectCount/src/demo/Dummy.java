package demo;

public class Dummy {
	// Count is static that it can be accessed
	// without making an object.
	static int count=0; 
	public Dummy(){
		// count increases whenever an object is created.
		count++;
	}
}
