package interfaces;

public interface Check extends Printable,NOnprint {
	public void checking();
}
