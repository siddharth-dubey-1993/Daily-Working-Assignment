package interfaces;

public class HR implements Printable{
	
	public void print(){
		System.out.println("Printing HR");
	}
	
}
