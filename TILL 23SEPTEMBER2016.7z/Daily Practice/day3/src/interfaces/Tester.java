package interfaces;

public class Tester extends Admin{
	
	public void print()
	{
	System.out.println("admin");
}
	
	public void demo()
	{
		System.out.println("testing");
	}

	public static void main(String[] args) {
		
		Tester t=new Tester();
		t.demo();
		t.print();

/*public class Tester extends HR{

	public static void main(String[] args) {
		HR h=new HR();
		h.print();
		

	}*/

}
}
