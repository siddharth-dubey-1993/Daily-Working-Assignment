package interfaces;

public interface NOnprint {
	public void noPrint();
}
