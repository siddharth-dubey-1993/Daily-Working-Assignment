package interfaces;

public abstract class Admin implements Printable {
	
	public abstract void demo();
	
	public abstract void print();

	
}
