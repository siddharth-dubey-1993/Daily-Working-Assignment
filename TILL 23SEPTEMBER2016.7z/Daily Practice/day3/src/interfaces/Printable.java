package interfaces;

public interface Printable {
	public void print();

}
