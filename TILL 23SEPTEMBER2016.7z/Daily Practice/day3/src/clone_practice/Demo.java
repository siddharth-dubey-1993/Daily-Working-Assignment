package clone_practice;

public class Demo {
	
	int a,b;

		

		public void method(int a, int b)
		{
			System.out.println(a+b);
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo c=new Demo();
		c.method(2,3);
		try {
			Demo c1=(Demo)c.clone();
			c1.method(1, 2);
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
	}

}
