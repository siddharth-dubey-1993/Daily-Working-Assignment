package overloading;

public  class Authentication {
	String userName;
	String password;
	int otp;
	String securityQues;
	
	public void login(String uname,String pwd){
		
		if((uname.equals("Siddharth"))&&(pwd.equals("Dubey"))){
			System.out.println("Login Successfull.");
		}
		else{
			System.out.println("Login Failed.");
		}
	}
	
	public void login(String uname,String pwd,int o){
		if((uname.equals("Siddharth"))&&(pwd.equals("Dubey"))&&(o==3489)){
			System.out.println("Login Successfull.");
		}
		else{
			System.out.println("Login Failed.");
		}
	}
	
	public void login(String uname,String pwd,int o,String sq){
		if((uname.equals("Siddharth"))&&(pwd.equals("Dubey"))&&(o==3489)&&(sq.equals("India"))){
			System.out.println("Login Successfull.");
		}
		else{
			System.out.println("Login Failed.");
		}
	}
	

}
