package overloading;

public class Tester extends Authentication {

	public static void main(String[] args) {
		
		Authentication a=new Authentication();
		a.login("Siddharth", "Dubey");
		Authentication a1=new Authentication();
		a1.login("Siddharth", "Dubey",3489);
		Authentication a2=new Authentication();
		a2.login("Siddharth", "Dubey",9999);
		Authentication a3=new Authentication();
		a3.login("Siddharth", "Dubey",3489,"India");
		Authentication a4=new Authentication();
		a4.login("Siddharth", "Dubey",3889,"India");
		Authentication a5=new Authentication();
		a5.login("Siddharth", "Dubey",3489,"China");

		
		
	}

}
