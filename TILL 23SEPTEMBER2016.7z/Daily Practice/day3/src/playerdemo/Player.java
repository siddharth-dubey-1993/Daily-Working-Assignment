package playerdemo;

public class Player {
	String name;
	int age;
	float height,weight;
	
	
	
	public Player(String name, int age, float height, float weight) {
		super();
		this.name = name;
		this.age = age;
		this.height = height;
		this.weight = weight;
	}
	
	
}
