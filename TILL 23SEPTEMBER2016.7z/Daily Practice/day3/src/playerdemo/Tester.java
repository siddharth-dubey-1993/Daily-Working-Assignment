package playerdemo;

public class Tester {

	public static void main(String[] args) {
		
		CricketPlayer ckp=new CricketPlayer("Sachin", 40, 5.5f, 62.5f, 3200, "opener");
		ckp.display();
		ckp.play();
		
		FootballPlayer fp = new FootballPlayer("Messi", 55, 4.0f, 112.8f, 5000, "Centre Forward");
		fp.display();
		fp.play();
		
		
		
			
		
	}

}
