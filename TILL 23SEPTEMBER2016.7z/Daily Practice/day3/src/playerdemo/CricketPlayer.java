package playerdemo;

import java.util.Scanner;

public class CricketPlayer extends Player {
	int runs;
	String role;
	
	
	public CricketPlayer(String name, int age, float height, float weight, int runs, String role) {
		super(name, age, height, weight);
		this.runs = runs;
		this.role = role;
	}
	
	public void display()
	{
		System.out.println("the player details are: name:"+name+" age:"+age+" height:"+height+" weight:"+weight+" runs:"+runs+" role:"+role);
	}
	
	public void play()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of overs played:");
		int o=sc.nextInt();
		System.out.println("the strike rate is:"+runs/o);
		
		
	}
	

}
