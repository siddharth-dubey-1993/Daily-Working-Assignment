package playerdemo;

import java.util.Scanner;

public class FootballPlayer extends Player {
	int goals;
	String position;
	
	
	
	public FootballPlayer(String name, int age, float height, float weight, int goals, String position) {
		super(name, age, height, weight);
		this.goals = goals;
		this.position = position;
	}
	
	public void display()
	{
		System.out.println("the player details are: name:"+name+" age:"+age+" height:"+height+" weight:"+weight+" goals:"+goals+" position:"+position);
	}
	
	public void play(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of matches played:");
		int m=sc.nextInt();
		
		System.out.println("Average goals per match:"+goals/m);
		
	}
	

}
