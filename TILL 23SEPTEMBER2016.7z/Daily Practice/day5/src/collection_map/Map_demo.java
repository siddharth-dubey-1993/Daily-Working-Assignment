package collection_map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class Map_demo {

	public static void main(String[] args) {
		
		Student s1=new Student("Tuhina",60);
		Student s2=new Student("Sid",70);
		Student s3=new Student("Vivek",50);
		Map<Integer,Student> tm= new TreeMap<>();
		tm.put(101, s1);
		tm.put(102, s2);
		tm.put(103, s2);
		ArrayList al= new ArrayList<>();
		al.add(s1.getMarks());
		al.add(s2.getMarks());
		al.add(s3.getMarks());
		
		
		
		//for(Map.Entry m: tm.entrySet())
		//{
		//	System.out.println(m.getKey());
		//	System.out.println(m.getValue());
		//}
		
		Collections.sort(al);
		System.out.println(al);
		
		

	}

}
