package collection_SetList;

import java.util.*;

public class Set_demo {

	public static void main(String[] args) {
		Set s=new TreeSet();
		/*s.add("one");
		s.add("2");
		s.add("three");
		s.add("4");
		*/s.add(new Integer(4));
		s.add(new Integer(44));
		s.add(new Integer(5));
//		s.add(new Float(8.9f));
/*		s.add("one");
*/		
		System.out.println(s);

	}

}
