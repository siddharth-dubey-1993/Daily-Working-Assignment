package collection_SetList;

import java.util.*;

public class Add {

	public static void main(String[] args) {
		List<Integer> l1= new ArrayList<>();
		l1.add(1);
		l1.add(5);
		l1.add(3);
		l1.add(9);
		l1.add(10);
		System.out.println(l1);
		
		List<Integer> l2= new ArrayList<>();
		l2.add(0);
		l2.add(5);
		l2.add(6);
		l2.add(9);
		l2.add(17);
		System.out.println(l2);
		
		List<Integer> l5= new ArrayList<>();
		l5.addAll(l1);
		l5.addAll(l2);
		System.out.println(l5);
		
		System.out.println(Collections.min(l1));
		System.out.println(Collections.max(l2));

	}

}
