package collection_SetList;

import java.util.*;

public class Intersection {

	public static void main(String[] args) {
		List<Integer> l1= new ArrayList<>();
		l1.add(1);
		l1.add(5);
		l1.add(3);
		l1.add(9);
		l1.add(10);
		System.out.println(l1);
		
		List<Integer> l2= new ArrayList<>();
		l2.add(0);
		l2.add(5);
		l2.add(6);
		l2.add(9);
		l2.add(17);
		System.out.println(l2);
		
		List<Integer> l4= new ArrayList<>();
		/*l3.addAll(l1);*/
		Iterator<Integer> itr=l2.iterator();
		
		while(itr.hasNext())
		{
			int i=itr.next();
			if(l1.contains(i))
				l4.add(i);
		}
		
		System.out.println(l4);

	}

}
