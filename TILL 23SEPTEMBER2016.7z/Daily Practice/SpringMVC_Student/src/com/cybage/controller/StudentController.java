/**
 * 
 */
package com.cybage.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cybage.model.Student;

/**
 * @author abhishekkumarr
 *
 */

@Controller

public class StudentController {
	@RequestMapping(value = "/Student", method=RequestMethod.GET)
public String HelloStudent(){
	System.out.println("in controler..");
	
	return "Student";
}
	@RequestMapping(value = "/Student", method=RequestMethod.POST)
	public String ValidateStudent(@ModelAttribute("Siddharth")Student student, ModelMap model){
		System.out.println("in controler.."+student);
		if(student!=null)
		{
			if(student.getStudentMailID()=="SIDD"||student.getPassword()=="DUBEY"){
				model.addAttribute("message", "WELCOME "+student.getStudentMailID());
				return "Success";
			}
			else
			{
				model.addAttribute("ERROR","MAIL ID or PASSWORD is Incorrect.");
				return "Student";
			}
		}
		else{
			model.addAttribute("ERROR", "Enter all the details");
			return "Student";
		}
	}
}
