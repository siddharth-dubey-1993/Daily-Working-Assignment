package com.cybage.model;

public class Student {
	private int studentID;
	private String studentName;
	private String password;
	private String StudentMailID;
	public Student(int studentID, String studentName, String password, String studentMailID) {
		super();
		this.studentID = studentID;
		this.studentName = studentName;
		this.password = password;
		StudentMailID = studentMailID;
	}
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStudentMailID() {
		return StudentMailID;
	}
	public void setStudentMailID(String studentMailID) {
		StudentMailID = studentMailID;
	}
	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", studentName=" + studentName + ", password=" + password
				+ ", StudentMailID=" + StudentMailID + "]";
	}
	
}
