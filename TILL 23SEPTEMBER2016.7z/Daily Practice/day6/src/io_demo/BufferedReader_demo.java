package io_demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferedReader_demo {

	public static void main(String[] args) {
		String str=null;
		System.out.println("enter ur name:");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try {
			 str=br.readLine();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("hello "+str);
		
	}

}
