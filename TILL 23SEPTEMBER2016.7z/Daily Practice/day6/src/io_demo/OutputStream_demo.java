package io_demo;

import java.io.DataOutputStream;
import java.io.IOException;

public class OutputStream_demo {

	public static void main(String[] args) {
		System.out.println("hello");
		

}
}
