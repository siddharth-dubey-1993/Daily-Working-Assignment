package io_demo;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class BufferedWriter_demo {

		BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(System.out));
		//bw.write();
		
}
