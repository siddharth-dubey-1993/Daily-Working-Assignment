package io_demo;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

public class InputStream_Demo {
	
	public static void main(String[] args) {
		int num=0;
		System.out.println("Enter the number:");
		DataInputStream is = new DataInputStream(System.in);
		try {
		
			num = (is.read());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=0;i<11;i++){
			System.out.println( i*num-48);
		}
		
	}

}
