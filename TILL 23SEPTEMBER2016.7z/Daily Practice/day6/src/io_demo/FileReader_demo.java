package io_demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class FileReader_demo {

	public static void main(String[] args) {
		
		String str;
		try {
			BufferedReader br=new BufferedReader(new FileReader("D:\\StudentDetails.dat"));
			PrintWriter pw=new PrintWriter(System.out);
			do{str=br.readLine();
			if(str==null)
				break;
			pw.println(str);
			}while(!true);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
