package serialization_demo;

import java.io.Serializable;

public class Student implements Serializable {
	
	private static final long serialVersionUID = -5021312285255333460L;
		String name;
		int rollNo;
		int marks;
		
		
		
		public Student(String name, int rollNo, int marks) {
			super();
			this.name = name;
			this.rollNo = rollNo;
			this.marks = marks;
		}



		@Override
		public String toString() {
			return "Student [name=" + name + ", rollNo=" + rollNo + ", marks=" + marks + "]";
		}
		
		
		

}
