package serialization_demo;

import java.io.Console;

public class Console_demo {

	public static void main(String[] args) 
	{
		Console console = System.console();

        console.printf("Please enter your username: ");
        String username = console.readLine();
        console.printf(username + "\n");

        console.printf("Please enter your password: ");
        char[] passwordChars = console.readPassword();
        String passwordString = new String(passwordChars);

        console.printf(passwordString + "\n");
		

	}

}
