/* @authored by TUHINA
 * 
 * Create a class customer to accept customer name, age and address
 * 
 * 
 * */




package pck_customer;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {

		Customer c=new Customer();

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter customer's name:\n");
		c.setName(sc.nextLine());

		System.out.println("Enter customer's address:\n");
		c.setAddress(sc.nextLine());

		System.out.println("Enter customer's age:\n");
		c.setAge(sc.nextInt());


		System.out.println(c.toString());

		sc.close();
	}

}
