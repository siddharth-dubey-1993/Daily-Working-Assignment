/* @authored by TUHINA
 * 
 *Write a class date.Overload the constructor to initialize the attributes.Create date
 *objects using non parameterized and parameterized constructors both.Print values of 
 *day,month and year of every object.
 * 
 * 
 * */
package pck_date;

public class Tester {

	public static void main(String[] args) {
		
		Date d= new Date();
		System.out.println("Day:"+d.getDay());
		System.out.println("Month:"+d.getMonth());
		System.out.println("Year:"+d.getYear());
		
		Date d1= new Date(22,"August",1960);
		System.out.println("Day:"+d1.getDay());
		System.out.println("Month:"+d1.getMonth());
		System.out.println("Year:"+d1.getYear());
	}

}
