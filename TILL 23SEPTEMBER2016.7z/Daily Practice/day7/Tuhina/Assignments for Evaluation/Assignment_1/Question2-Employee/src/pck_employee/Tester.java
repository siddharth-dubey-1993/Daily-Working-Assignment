/* @authored by TUHINA
 * 
 * Create a class Employee and write accessors and mutators.Create objects with
 *  default constructors and constructor with name,age and salary as parameters 
 *  to show overloading of constructors.Display or print values of attributes of
 *   each object.
 * 
 * 
 * */

package pck_employee;

public class Tester {

	public static void main(String[] args) {
		Employee e=new Employee();
		System.out.println(e.toString());
		
		Employee e1=new Employee("Sudha",50,300000);
		System.out.println(e1.toString());

	}

}
