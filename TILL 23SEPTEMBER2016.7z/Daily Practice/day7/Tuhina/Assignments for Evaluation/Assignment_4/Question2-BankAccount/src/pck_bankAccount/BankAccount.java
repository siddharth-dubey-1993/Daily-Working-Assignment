package pck_bankAccount;

public abstract class BankAccount {
	
	//data members
	long accountNumber;
	String accountHolder;
	double balance;
	float rateOfInterest;
	
	
	public BankAccount(long accountNumber, String accountHolder, double balance, float rateOfInterest) {
		
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.balance = balance;
		this.rateOfInterest = rateOfInterest;
	}


	
	
	//getters and setters
	public double getBalance() {
		return balance;
	}



	public void setBalance(double balance) {
		this.balance = balance;
	}



	public float getRateOfInterest() {
		return rateOfInterest;
	}



	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}


	//abstract method to calculate amount 
	public abstract double addInterest();
	
	
	
	

}
