package pck_bankAccount;

public class Current extends BankAccount {

		//data members
		int empId;

		
		
		//constructor
		 public Current(long accountNumber, String accountHolder, double balance, float rateOfInterest, int empId) {
			super(accountNumber, accountHolder, balance, rateOfInterest);
			this.empId = empId;
		}

		//method to calculate amount after a year
		public double addInterest() 
	     {
			 
	      return getBalance() * getRateOfInterest() / 100; 
	      
	      
	     }

		//overriding toString method
		@Override
		public String toString() {
			return "Current [ accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
					+",Employee id:"+empId + ", Amount added as interest per month=" + addInterest() + "]";
		}
}
