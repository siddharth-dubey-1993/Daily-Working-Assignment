package pck_bankAccount;

public class Saving extends BankAccount{

	
	
	//constructor
	 public Saving(long accountNumber, String accountHolder, double balance, float rateOfInterest) {
		super(accountNumber, accountHolder, balance, rateOfInterest);
		
	}

	//method to calculate amount after a year
	public double addInterest() 
     {
		 
     return getBalance() * getRateOfInterest() / 100; 
      
      
     }

	//overriding toString method
	@Override
	public String toString() {
		return "Saving [accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
				+ ", Amount added as interest per month=" + addInterest() + "]";
	}


	
	 
	 
 
}
