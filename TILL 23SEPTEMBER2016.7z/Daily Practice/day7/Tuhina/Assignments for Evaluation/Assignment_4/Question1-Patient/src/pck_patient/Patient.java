package pck_patient;

public class Patient extends Person {

	//data members
	int patientNumber;
	String hospital;
	int yearOfJoining;
	String address;
	double fees;


	//default constructor
	public Patient() {
		super();
		patientNumber=100;
		hospital="Care hospital";
		yearOfJoining= 2000;
		address="kalyaninagar,pune";
		fees=0;

	}



	//parameterized constructor
	public Patient(String name ,int age, int patientNumber, String hospital, int yearOfJoining, String address) {

		super(name, age);
		this.patientNumber = patientNumber;
		this.hospital = hospital;
		this.yearOfJoining = yearOfJoining;
		this.address = address;
		fees=0;
	}


	//getters and setters
	public String getHospital() {
		return hospital;
	}



	public void setHospital(String hospital) {
		this.hospital = hospital;
	}



	public int getYearOfJoining() {
		return yearOfJoining;
	}



	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	//overriding toString method
	@Override
	public String toString() {
		return "Patient [ name=" + name + ", age=" + age +"patientNumber=" + patientNumber + ", hospital=" + hospital + ", yearOfJoining=" + yearOfJoining
				+ ", address=" + address +  "]";
	}


	//method to calculate final bill on the basis of year of joining and basic fee
	public double calculateFees(Money m)
	{	
		Person p=new Patient("Tuhina",23,200,"Workhart",2006,"kolkata");

		double medicalFees= m.basicFee+((2016-((Patient) p).getYearOfJoining())*5000);
		return medicalFees;
	}



}
