package pck_patient;

public class Person {

	//data members
	String name;
	int age;

	//default constructor
	public Person() {
		super();
		name="Tuhina";
		age=23;
	}

	//parameterized constructor
	public Person(String name, int age) {

		this.name = name;
		this.age = age;
	}


}
