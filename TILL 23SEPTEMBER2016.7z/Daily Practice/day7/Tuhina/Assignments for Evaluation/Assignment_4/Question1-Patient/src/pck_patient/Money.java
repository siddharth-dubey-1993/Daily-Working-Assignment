package pck_patient;

public class Money {
	//data members
	double basicFee=120050;
}
