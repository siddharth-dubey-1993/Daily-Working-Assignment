/*
 *   @authored by TUHINA
 *   
 *   
 * */


package pck_patient;

public class Tester {

	public static void main(String[] args) {
		Patient p=new Patient();
		Money m= new Money();
		System.out.println(p.toString()+"\n Your final bill:"+p.calculateFees(m));

	}

}
