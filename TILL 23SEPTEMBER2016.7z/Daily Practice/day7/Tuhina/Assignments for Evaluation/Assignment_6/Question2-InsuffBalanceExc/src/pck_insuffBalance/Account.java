/*
*	@authored by TUHINA
*	Create an InsufficientBalanceException to be thrown by withdraw() method in Account class if amount to be withdrawn is greater than balance
*/
package pck_insuffBalance;

public class Account {
	
	//data member
	int balance;
	

	//method to check balance before withdrawing
	public void withdraw(int amt)throws InsufficientBalanceException
	{
		
		
		if(amt>balance) throw new InsufficientBalanceException("you do not have enough balance ");
		else
		System.out.println( "Amount successfully withdrawn");
	}
	

	public static void main(String[] args)  {
		
		int amount=Integer.parseInt(args[0]);
		Account a= new Account();
		try{
			a.withdraw(amount);
		}
		catch(InsufficientBalanceException e)
		{
			System.out.println(e.getMessage());
		}
	}

}
