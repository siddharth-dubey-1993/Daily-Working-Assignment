package pck_insuffBalance;

//exception to check balance without withdrawing
public class InsufficientBalanceException extends RuntimeException {

		public InsufficientBalanceException(String s) {
			super(s);
		};
		
}
