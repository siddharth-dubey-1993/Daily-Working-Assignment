package pck_machine;

//exception to check power availability
public class NoElectricityException extends RuntimeException {

	public NoElectricityException(String s)
	{
		super(s);
	}
}
