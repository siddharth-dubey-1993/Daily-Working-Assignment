/*	@authored by TUHINA 
 * 
 * 	Create a machine which has start stop and execute functionality and carefully
 *  handle sudden exceptions for the effective working of machine.
 * */

package pck_machine;



public class LiftMachine {

	//data members
	int noOfPersons;
	boolean powerAvailable;




	//method to check excess load and power availability before starting the lift
	public void start(int n,boolean p)throws ExcessLoadException,NoElectricityException
	{
		if(n>17) 
			throw new ExcessLoadException("Load exceeded");
		else if(p==false)
			throw new NoElectricityException("No Electricity,sorry for the inconvenience");
		else
			System.out.println("goodmorning,press floor button to proceed");
	}


	//method to stop the lift if power not available
	public void stop(boolean p)throws NoElectricityException
	{
		if(p==false)
			throw new NoElectricityException("No Electricity,sorry for the inconvenience");
	}



	public static void main(String[] args) {

		LiftMachine lm=new LiftMachine();
		try{
			lm.start(16,true);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		try{
			lm.start(20,true);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		try{
			lm.start(16,false);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
			lm.stop(true);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
			lm.stop(false);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

}
