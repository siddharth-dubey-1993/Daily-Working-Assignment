package pck_machine;

//exception to check excees load on lift
public class ExcessLoadException extends RuntimeException{

	public ExcessLoadException(String s)

	{
		super(s);
	}
}
