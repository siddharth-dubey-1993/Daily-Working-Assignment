package pck_hashMap;

import java.util.HashMap;
import java.util.Iterator;

public class HashMap_demo {

	public static void main(String[] args) {
		HashMap<Books,Integer> hm=new HashMap<>();
		hm.put(new Books("Inferno","Dan Brown",500, "A1234B"), 567);
		hm.put(new Books("Zero K","Don Delilo",400, "D1234C"), 345);
		hm.put(new Books("Homegoing","Yaa Gyasi",450, "C1234B"), 660);
		hm.put(new Books("before The Fall","Noah Hawley",350, "A1289D"), 230);


		Iterator itr = hm.keySet().iterator();
		while (itr.hasNext()) {
			Books key= (Books) itr.next();
			Integer value=(Integer)hm.get(key);

			System.out.println("Book:"+key+" Number of Pages:"+value);


		}
	}
}
