package pck_hashMap;

public class Books {

	//data members
	String bookName;
	String authorName;
	double price;
	String isbl;

	//constructor
	public Books(String bookName, String authorName, double price, String isbl) {
		
		this.bookName = bookName;
		this.authorName = authorName;
		this.price = price;
		this.isbl = isbl;
	}

	//overriding toString
	@Override
	public String toString() {
		return "Books [bookName=" + bookName + ", authorName=" + authorName + ", price=" + price + ", isbl=" + isbl
				+ "]";
	}

	//overriding hashcode
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isbl == null) ? 0 : isbl.hashCode());
		return result;
	}

	//overriding equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;

		Books other = (Books) obj;
		if (isbl == null) {
			if (other.isbl != null)
				return false;
		} else if (!isbl.equals(other.isbl))
			return false;
		return true;
	}





}
