package pck_person_collection;

import java.util.ArrayList;
import java.util.Iterator;

public class MenuDriven {

	public static void main(String[] args) {

		ArrayList<Person> al=new ArrayList<>();
		al.add(new Patient("Drishti", 24, 101, "Workhart Hospital", 2014, "Delhi", 20000));
		al.add(new Patient("Sahiba", 23, 102, "Sahyadri Hospital", 2015, "Chandigarh", 15000));
		al.add(new Patient("Mandar", 23, 103, "GoodWill Hospital", 2016, "Nagpur", 12000));
		al.add(new Patient("Charles", 24, 104, "Aims Hospital", 2015, "Delhi", 11000));
		al.add(new Patient("Chirag", 23, 105, "OrangeCity Hospital", 2015, "Nagpur", 13000));

		System.out.println("press 1. to  create record\n press 2. to update patient's "
				+ "address\n press 3. remove patient's record\n 4.to get size of records\n");
		switch(args[0])
		{

		case "1":
			//to add record at the end of the list
			al.add(new Patient("Tuhina", 23, 105, "Care Hospital", 2015, "WB", 10000));
			System.out.println("record added\n");
			System.out.println(al.toString());
			break;


		case "2":
			//to update address of patient
			Iterator<Person> itr = al.iterator();
			Patient p=null;
			while(itr.hasNext())
			{
				p=(Patient) itr.next();
				if(p.getPatientNumber()==103)
				{
					p.setAddress("MH");
					break;
				}


			}
			System.out.println("updated");
			System.out.println(p);

			break;

		case "3":
			//to remove record from index "1"
			System.out.println("record "+al.get(1)+" removed");
			al.remove(1);
			break;

		case "4":
			//to get size of arraylist
			System.out.println(al.size());
			break;

		default: System.out.println("wrong choice");
		break;
		}

	}

}
