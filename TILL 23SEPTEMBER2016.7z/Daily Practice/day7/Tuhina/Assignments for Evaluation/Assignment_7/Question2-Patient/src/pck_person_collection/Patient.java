package pck_person_collection;

public class Patient extends Person {

	//data members
	int patientNumber;
	String hospital;
	int yearOfJoining;
	String address;
	double fees;


	//constructor
	public Patient(String name, int age, int patientNumber, String hospital, int yearOfJoining, String address,
			double fees) {
		super(name, age);
		this.patientNumber = patientNumber;
		this.hospital = hospital;
		this.yearOfJoining = yearOfJoining;
		this.address = address;
		this.fees = fees;
	}


	public int getPatientNumber() {
		return patientNumber;
	}


	public void setPatientNumber(int patientNumber) {
		this.patientNumber = patientNumber;
	}


	//getter and setter for address
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Patient [name=" + name + ", age=" + age+",patientNumber=" + patientNumber + ", hospital=" + hospital + ", yearOfJoining=" + yearOfJoining
				+ ", address=" + address + ", fees=" + fees + " ]";
	}







}
