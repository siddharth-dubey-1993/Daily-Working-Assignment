package pck_emp;

import java.util.Comparator;

public class EmpIdComparator implements Comparator<Employee> {

	//method to sort on the basis of employee id
	@Override
	public int compare(Employee e1, Employee e2) {
		if(e1.getEmpId()>e2.getEmpId())
			return 1;
		if(e1.getEmpId()<e2.getEmpId())
			return -1;
		else

			return 0;



	}


}
