/* @authored by TUHINA
 * 
 * Create a sorted set of Employee objects. Sort on the basis of employee id.
 * 
 * */
package pck_emp;

import java.util.TreeSet;

public class TreeSet_demo {

	public static void main(String[] args) {
		TreeSet<Employee> ts=new TreeSet<Employee>(new EmpIdComparator());
		ts.add(new Employee(101,"Tuhina",20000));
		ts.add(new Employee(102,"Drishti",30000));
		ts.add(new Employee(105,"Charles",40000));
		ts.add(new Employee(106,"Chirag",35000));
		ts.add(new Employee(103,"Sahiba",50000));
		ts.add(new Employee(104,"Mandar",45000));

		for(Employee e:ts)
			System.out.println(e);

	}

}
