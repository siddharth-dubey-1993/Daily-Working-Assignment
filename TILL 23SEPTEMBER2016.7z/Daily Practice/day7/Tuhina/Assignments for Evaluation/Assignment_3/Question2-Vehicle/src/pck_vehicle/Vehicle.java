package pck_vehicle;

public class Vehicle {

	//methods
	

	public void move()
	{
		System.out.println("moving");
	}

}
