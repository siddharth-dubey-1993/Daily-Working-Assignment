package pck_vehicle;

public class Truck extends Vehicle {

	//overriden method
	public void move()
	{
		System.out.println("truck moving on 8 wheels");
	}
}
