/*
 *    @authored by TUHINA
 *    
 * Create a class hierarchy Animal extended by classes Cat,Dog and Lion. Animal class will 
 * have methods like respirate() and move(). Override method move() in each of its subclass.
 * Create an array of animal reference and observe dynamic polymorphism.
 *  
 * */


package pck_vehicle;

public class Tester {

	public static void main(String[] args) {
		Vehicle a1[]={new Vehicle(),new Car(),new Motorbike(),new Truck()};
	
		a1[0].move();
		a1[1].move();
		a1[2].move();
		a1[3].move();

	}

}
