package pck_vehicle;

public class Car extends Vehicle{

	//overriden method
	public void move()
	{
		System.out.println("car moving on 4 wheels");
	}
}
