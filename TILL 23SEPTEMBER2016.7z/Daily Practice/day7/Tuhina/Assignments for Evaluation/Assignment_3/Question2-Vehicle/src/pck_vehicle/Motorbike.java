package pck_vehicle;

public class Motorbike extends Vehicle {


	//overriden method
	public void move()
	{
		System.out.println("motorbike moving on 2 wheels");
	}
}
