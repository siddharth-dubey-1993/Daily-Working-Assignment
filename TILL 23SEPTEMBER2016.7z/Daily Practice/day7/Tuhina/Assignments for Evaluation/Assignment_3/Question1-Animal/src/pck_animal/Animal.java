package pck_animal;

public class Animal {

	//methods
	public void respirate()
	{
		System.out.println("Respirating");
	}

	public void talk()
	{
		System.out.println("talking");
	}

}
