package pck_animal;

public class Cat extends Animal{

	//overriden method
	public void talk()
	{
		System.out.println("meowww");
	}
}
