package pck_animal;

public class Lion extends Animal {

	//overriden method
	public void talk()
	{
		System.out.println("grrrrrr");
	}
}
