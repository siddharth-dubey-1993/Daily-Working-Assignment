/*
 *    @authored by TUHINA
 *    
 * Create a class hierarchy Animal extended by classes Cat,Dog and Lion. Animal class will 
 * have methods like respirate() and talk(). Override method talk() in each of its subclass.
 * Create an array of animal reference and observe dynamic polymorphism.
 *  
 * */


package pck_animal;

public class Tester {

	public static void main(String[] args) {
		Animal a1[]={new Animal(),new Cat(),new Dog(),new Lion()};
		a1[0].respirate();
		a1[0].talk();
		a1[1].talk();
		a1[2].talk();
		a1[3].talk();

	}

}
