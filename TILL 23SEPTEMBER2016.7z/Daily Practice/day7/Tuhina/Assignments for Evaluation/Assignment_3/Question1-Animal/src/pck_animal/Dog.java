package pck_animal;

public class Dog extends Animal {


	//overriden method
	public void talk()
	{
		System.out.println("bhow wow");
	}
}
