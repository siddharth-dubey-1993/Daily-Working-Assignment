package pck_printable;

//interface
public interface Printable {

	public void print();
}
