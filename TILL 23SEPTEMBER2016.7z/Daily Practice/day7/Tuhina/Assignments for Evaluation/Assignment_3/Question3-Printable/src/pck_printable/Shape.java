package pck_printable;

public class Shape implements Printable{
	
	//overriden method
	@Override
	public void print() {
		System.out.println("printing shape");

	}

}
