/*
 *    @authored by TUHINA
 *    
 * Create an interface: Printable-method print(). Write a class Utility to have a 
 * method printAll(Printable[]).Pass different objects(Shape and Animal) to printAll() to print them.
 *  
 * */
package pck_printable;

public class Utility {

	public void printAll(Printable pr[])
	{
		for(int i=0;i<pr.length;i++)
		{
			pr[i].print();
		}
	}

	public static void main(String[] args) {

		Utility u=new Utility();
		Printable arr[]={new Shape(),new Animal()};
		u.printAll(arr);
	}

}
