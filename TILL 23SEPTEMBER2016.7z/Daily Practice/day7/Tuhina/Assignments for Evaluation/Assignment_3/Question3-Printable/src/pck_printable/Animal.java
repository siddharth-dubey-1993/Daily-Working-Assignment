package pck_printable;

public class Animal implements Printable {
	
	//overriden method
	@Override
	public void print() {
		System.out.println("printing animal");

	}


}
