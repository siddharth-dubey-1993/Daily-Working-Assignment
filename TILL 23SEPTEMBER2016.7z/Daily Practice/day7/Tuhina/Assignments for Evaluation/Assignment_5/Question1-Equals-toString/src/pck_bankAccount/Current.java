package pck_bankAccount;

public class Current extends BankAccount {

		//data members
		int empId;

		
		
		//constructor
		 public Current(long accountNumber, String accountHolder, double balance, float rateOfInterest, int empId) {
			super(accountNumber, accountHolder, balance, rateOfInterest);
			this.empId = empId;
		}

		//to calculate amount after a year
		public double addInterest() 
	     {
		  
			return getBalance()+(getBalance() * getRateOfInterest() / 100); 
	      
	      
	     }

		//overriding toString method
		@Override
		public String toString() {
			return "Current [ accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
					+",Employee id:"+empId + ", Amount at the end of one year=" + addInterest() + "]";
		}
		
		
}
