/*  @authored by TUHINA
* 	Override equals() and toString() in Employee and Account class
*
*/


package pck_bankAccount;

public class Tester {

	public static void main(String[] args) {
		BankAccount s=new Saving(10101010, "Tuhina", 30000, 11.5f);
		s.addInterest();
		System.out.println(s.toString());
		
		BankAccount c=new Current(20202020,"Tuhina",30000, 8.5f, 100);
		c.addInterest();
		System.out.println(c.toString());
			
		
		if(c.equals(s))
			System.out.println("the current and savings account belong to the same person");
		else
			System.out.println("the cuurent and saving accounts are of different persons");
		
		

	}

}
