package pck_bankAccount;

public abstract class BankAccount {
	
	//data members
	long accountNumber;
	String accountHolder;
	double balance;
	float rateOfInterest;
	
	
	public BankAccount(long accountNumber, String accountHolder, double balance, float rateOfInterest) {
		
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.balance = balance;
		this.rateOfInterest = rateOfInterest;
	}


	
	
	//getters and setters
	public double getBalance() {
		return balance;
	}



	public void setBalance(double balance) {
		this.balance = balance;
	}



	public float getRateOfInterest() {
		return rateOfInterest;
	}



	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}



	public abstract double addInterest();



	//overriding hashcode method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountHolder == null) ? 0 : accountHolder.hashCode());
		return result;
	}



	//overriding equals method
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		
		BankAccount other = (BankAccount) obj;
		if (accountHolder == null) {
			if (other.accountHolder != null)
				return false;
		} else if (!accountHolder.equals(other.accountHolder))
			return false;
		return true;
	}




	
	
	
	
	

}
