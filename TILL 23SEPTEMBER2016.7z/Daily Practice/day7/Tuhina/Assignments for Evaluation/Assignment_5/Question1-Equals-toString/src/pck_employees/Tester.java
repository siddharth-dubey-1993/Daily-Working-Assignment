/*		@authored by  TUHINA
*
*	Override equals() and toString() method in Account and Employees class.
*
*/

package pck_employees;

public class Tester {

	public static void main(String[] args) {
		Employees e=new Employees(101,"Tuhina", 300000);
		Employees e1=new Employees(101,"Tuhi", 300000);
		
		System.out.println(e.toString());
		
		if(e.equals(e1))
			System.out.println("Referred to same employee");
		else
			System.out.println("Employees are different");
	}
}
