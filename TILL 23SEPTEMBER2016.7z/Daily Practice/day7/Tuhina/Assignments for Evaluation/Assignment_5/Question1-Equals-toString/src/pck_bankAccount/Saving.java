package pck_bankAccount;

public class Saving extends BankAccount{

	
	
	//constructor
	 public Saving(long accountNumber, String accountHolder, double balance, float rateOfInterest) {
		super(accountNumber, accountHolder, balance, rateOfInterest);
		
	}

	//to calculate amount after a year
	public double addInterest() 
     {
		return getBalance() * Math.pow(1+(getRateOfInterest()/2), 2) ; 
      
      
      
     }

	//overriding toString method
	@Override
	public String toString() {
		return "Saving [accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
				+ ", Amount at the end of one year=" + addInterest() + "]";
	}


	
	 
	 
 
}
