/*	@authored by TUHINA
*
*	Accept numbers from command line arguments and sort them.
*
*/

package pck_sort;

public class Sort {

	public static void main(String[] args) {
		
		int arr[]=new int[5];
		int temp;
		System.out.println("the numbers to be sorted are:\n");
		
		//converting string command line arguments to integer array
		for(int i=0;i<args.length;i++)
		{	
			
			arr[i]=Integer.parseInt(args[i]);
			System.out.println(arr[i]);
			
		}
		
		//using bubble sort to sort in ascending orders
		for(int j=0;j<arr.length;j++)
		{
			for(int k=j+1;k<arr.length;k++)
			{
				if(arr[j]>arr[k])
				{
					temp=arr[j];
					arr[j]=arr[k];
					arr[k]=temp;
				
				}
			}
		}
		
		//printing the sorted array
		System.out.println("the numbers in ascending order are:");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

}
