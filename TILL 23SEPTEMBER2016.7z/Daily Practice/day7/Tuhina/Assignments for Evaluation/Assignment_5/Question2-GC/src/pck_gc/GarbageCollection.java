/*	@authored by TUHINA
 * Call system.gc(). Check whether GC runs or not.
 * 
 * */

package pck_gc;

public class GarbageCollection {

	public static void main(String[] args) {
		
		Fruit f= new Fruit("apple",50);
		System.out.println(f);
		
		f=null;
		
		System.gc();

	}

}
