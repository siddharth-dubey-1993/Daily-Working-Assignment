package pck_gc;

public class Fruit {

	//data members
	String name;
	int price;
	
	//parameterized constructor
	public Fruit(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}
	
	//overriding finalize method
	@Override
	protected void finalize() throws Throwable {
		System.out.println("This fruit is removed");
	}
	
	


}
