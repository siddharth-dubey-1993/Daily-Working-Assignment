/* @authored by TUHINA
*
*	Create a class Calc inside a package utility. This class will have a method findRoot()
*	which will return square root of a number. Create another class User1 inside a package allUser.
*	user1 calls findRoot() to get square root of a number. these two packages should be in
*   different directories located in two different drives.
*/
package allUser;

import utlity.Calc;


public class User1 {

	public static void main(String[] args) {
		
		int num=Integer.parseInt(args[0]);
		System.out.println(Calc.findRoot(num));
	}

}
