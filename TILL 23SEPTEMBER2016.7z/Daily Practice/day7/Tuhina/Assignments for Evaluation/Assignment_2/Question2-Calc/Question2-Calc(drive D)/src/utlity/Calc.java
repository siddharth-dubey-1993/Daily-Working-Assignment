package utlity;

public class Calc {
		
		//method to find square root
		public static double findRoot(double num)
		{
			return Math.sqrt(num);
		}
}
