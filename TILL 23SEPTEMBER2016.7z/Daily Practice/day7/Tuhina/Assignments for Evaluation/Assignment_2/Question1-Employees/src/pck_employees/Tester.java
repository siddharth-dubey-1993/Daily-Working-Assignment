/*
 *    @authored by TUHINA
 *    
 * Create an array of Employees and display the number of Employee objects created.
 *  
 * */


package pck_employees;

public class Tester {

	public static void main(String[] args) {
		System.out.println("The number of objects created before:"+Employees.count);
		Employees e[]= {new Employees(101,"Tuhina",20000),new Employees(102,"Sudha",30000),new Employees(103,"Basu",40000)};


		for(int i=0;i<Employees.count;i++)
		{
			System.out.println("Employee name:"+e[i].getName()+"Employee id:"+e[i].getEmpId()+"Employee salary:"+e[i].getSalary());
		}

		System.out.println("The number of objects created after:"+Employees.count);
	}

}
