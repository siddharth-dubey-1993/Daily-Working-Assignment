/* Code for printing the table of any number using for each 
 * loop where number is taken as command line argument*/

public class Tester {

	public static void main(String[] args) {
		// Array to keep the table from 1 to 10.
		int arr[]={1,2,3,4,5,6,7,8,9,10};
		int num=Integer.parseInt(args[0]);
		// For printing the table.
		for(int i:arr){
			System.out.println(arr[i-1]*num);
		}
	}

}
