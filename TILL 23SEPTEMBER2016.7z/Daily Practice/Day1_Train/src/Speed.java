
public class Speed {
	
	float speed;
	float avgSpeed;

}
