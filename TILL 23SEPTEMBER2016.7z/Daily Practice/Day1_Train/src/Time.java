
public class Time {
	
	float startTime;
	float endTime;
	float journeyTime;

}
