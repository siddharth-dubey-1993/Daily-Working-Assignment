
public class Seating {
	
	int noOfBogies;
	int totalNumSeat;
	
}
