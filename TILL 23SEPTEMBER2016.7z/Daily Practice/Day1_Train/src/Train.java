
public class Train {
	int trainNum;
	String trainName;
	String startStation;
	String endStation;
	String trainType;
	//String stopages[];
	
	
	
	
	
	
	
	
}
