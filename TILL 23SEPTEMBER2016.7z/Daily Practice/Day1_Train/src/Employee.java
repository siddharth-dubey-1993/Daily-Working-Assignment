
public class Employee {

	String pilotName;
	int pilotId;
	String coPilotName;
	int copilotId;
	String guardName;
	int guardId;
	String tteName;
	
}
