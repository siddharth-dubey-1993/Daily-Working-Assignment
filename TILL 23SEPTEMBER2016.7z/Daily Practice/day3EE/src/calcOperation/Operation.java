package calcOperation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Addition
 */
@WebServlet("/Operation")
public class Operation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Operation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		int val1 = Integer.parseInt(request.getParameter("num1"));
		int val2 = Integer.parseInt(request.getParameter("num2"));
		String oper = (String) request.getParameter("r1");
		PrintWriter out = response.getWriter();
		
		double result = 0;
		
		switch (oper) {
		case "add":
			result= val1+val2;
			break;
		case "mul":
			result=val1*val2;
			break;
		case "div":
			result=val1/val2;
			break;
		case "sub":
			result=val1-val2;
			break;
		default:
			System.out.println("no operation given");
			break;
		}
		out.println("<form action='Result'> ");
		out.println("<input type= 'hidden' name='result' value='"+result+"'>");
		out.println("<input type= 'submit' value='Submit'>");
		out.println("</form>");
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		/*int val1 = (int) request.getAttribute("num1");
		int val2 =(int) request.getAttribute("num2");
		String oper = (String) request.getAttribute("r1");
		PrintWriter out = response.getWriter();
		
		double result = 0;
		
		switch (oper) {
		case "add":
			result= val1+val2;
			break;
		case "mul":
			result=val1*val2;
			break;
		case "div":
			result=val1/val2;
			break;
		case "sub":
			result=val1-val2;
			break;
		default:
			System.out.println("no operation given");
			break;
		}
		out.println("<form action='welcome'> ");
		out.println("<input type= 'hidden' name='result' value='"+result+"'>");
		out.println("<input type= 'submit' value='Submit'>");
		out.println("</form>");*/
		
	}

}
