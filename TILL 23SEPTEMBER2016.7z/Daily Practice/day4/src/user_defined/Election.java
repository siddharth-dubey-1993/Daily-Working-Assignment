package user_defined;


public class Election {
		
		public void checkAge(int age) throws AgeLimitException
		{
			try{
				if (age<18)
					throw new AgeLimitException("\nyou should be above 18 years to vote");
				else
					System.out.println("valid to vote");
			}
			catch(AgeLimitException e)
			{
				System.out.println(e);
			}
		}

	public static void main(String[] args) {
		Election e=new Election();
		e.checkAge(16);
		e.checkAge(18);
		e.checkAge(55);
	}

}
