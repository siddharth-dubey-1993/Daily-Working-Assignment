package user_defined;

public class AgeLimitException extends RuntimeException{
	public AgeLimitException(String s) {
		super(s);
	}
}
