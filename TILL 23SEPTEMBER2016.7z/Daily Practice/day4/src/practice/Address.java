package practice;

public class Address {
	int houseNo;
	String streetName;
	String locality;
	String city;
	int pinCode;
	String state;
	
	
	
	/*public Address(int houseNo, String streetName, String locality, String city, int pinCode, String state) {
		super();
		this.houseNo = houseNo;
		this.streetName = streetName;
		this.locality = locality;
		this.city = city;
		this.pinCode = pinCode;
		this.state = state;
	}*/



	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", streetName=" + streetName + ", locality=" + locality + ", city="
				+ city + ", pinCode=" + pinCode + ", state=" + state + "]";
	}
	
	
	
}
