package practice;



public class Employee{
	String name;
	int eid;
	Address a;
	
	
	
	
	

	
	/*public Employee(String name, int eid, Address a) {
		super();
		this.name = name;
		this.eid = eid;
		this.a = a;
	}*/

	public void display() throws Exception
	{	
		/*Address a1=new Address(12,"hd","dsff","fdsdsf",5445,"fdds");
		Employee e1=new Employee("ujhbu",5646,a1);
		Address a2=new Address(12,"hd","dsff","fdsdsf",5445,"fdds");
		Employee e2=new Employee("ujhbu",5646,a2);
		Address a3=new Address(12,"hd","dsff","fdsdsf",5445,"fdds");
		Employee e3=new Employee("ujhbu",5646,a3);*/
		Employee emp[]=new Employee[3];
		for(int i=0;i<6;i++)
		{
			
			Employee e=new Employee();
			if(i>3) throw new ArrayIndexOutOfBoundsException();
			else
				emp[i]=e;
		}
		
	}





	public static void main(String args[]) throws Exception{
		
		
		try{
			Employee e1= new Employee();
			e1.display();
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Exception found:"+e);
		}
		
	
		
	}




	
}
