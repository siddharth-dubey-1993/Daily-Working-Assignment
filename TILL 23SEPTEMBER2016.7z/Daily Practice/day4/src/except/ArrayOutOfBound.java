package except;

public class ArrayOutOfBound {

	public static void main(String[] args) {
		int arr[] = {1,7,8};
		
		System.out.println(arr[4]);
	}

}
