package except;

public class Exception {

	public static void main(String[] args) {
		String s= null;
		s.length();

	}

}
