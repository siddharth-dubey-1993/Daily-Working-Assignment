/* Code for printing whether the number provided
 *  through command line is a perfect number or not. */

public class Tester {
	
	// To check whether the number is perfect or not.
	public static void main(String[] args) {
		int num=Integer.parseInt(args[0]);
		int sum=0;
		for(int i=1;i<num;i++){
			if((num%i)==0){
				sum=sum+i;
			}
		}
		if(sum==num){
			System.out.println(num+" is a perfect number.");
		}
		else{
			System.out.println(num+" is not a perfect number.");
		}
	}

}
