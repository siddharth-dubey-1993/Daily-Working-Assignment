package thread_demo;

public class Array_demo {

	public void printArray(){
		synchronized(this){
			String arr[] ={"First","Second","Third","Four","Fifth"};
		
			for (int i = 0; i < arr.length; i++) {
				System.out.println(arr[i]);
			}
		}
		
	}
}
	