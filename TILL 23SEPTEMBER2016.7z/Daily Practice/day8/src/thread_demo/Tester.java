package thread_demo;

class Thread1 extends Thread{  
	
	Array_demo ad1;  
	Thread1(Array_demo ad1){  
		this.ad1=ad1;  
	}  
	public void run(){  
		ad1.printArray();
	}
}

class Thread2 extends Thread{  
	Array_demo ad2;  
	Thread2(Array_demo ad2){  
		this.ad2=ad2;  
	}  
	public void run(){  
		ad2.printArray();
	} 
}





public class Tester {


	public static void main(String[] args) {
		
		Array_demo obj = new Array_demo(); 
		Thread1 t1=new Thread1(obj);  
		Thread2 t2=new Thread2(obj);  
		t1.start();  
		t2.start();  




	}

}
