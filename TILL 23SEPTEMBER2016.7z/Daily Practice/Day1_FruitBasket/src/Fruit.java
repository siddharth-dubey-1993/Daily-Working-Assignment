
public class Fruit {
	int tos = length-1;
	int bos = 0;
	int fruitItem
	
}
