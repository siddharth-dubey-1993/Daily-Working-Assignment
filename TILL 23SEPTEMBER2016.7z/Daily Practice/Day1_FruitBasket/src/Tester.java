
public class Tester {

	public static void main(String[] args) {
		final int length = 10;
		Fruit Fr = new Fruit(length);
		
		
		
		
	}

}
