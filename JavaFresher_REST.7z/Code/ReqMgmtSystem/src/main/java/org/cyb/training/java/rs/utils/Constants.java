package org.cyb.training.java.rs.utils;

public class Constants {

	public enum ReqState {
		Backlog,
		Active,
		Closed
	}
	
}
